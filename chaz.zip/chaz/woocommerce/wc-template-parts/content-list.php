<?php
global $wc_loop_i;
$short_description = apply_filters( 'woocommerce_short_description', $post->post_excerpt );
$opt = get_option('chaz_opt');
global $product;
?>

<div <?php wc_product_class(' media pr_list'); ?>>
    <?php if (woocommerce_get_product_thumbnail()) : ?>
        <div class="media-left">
            <?php woocommerce_template_loop_product_thumbnail() ?>
        </div>
    <?php endif; ?>
    <div class="media-body">
        <div class="single_product_item">
            <div class="single_pr_details">
                <a href="<?php the_permalink() ?>">
                    <h2> <?php the_title(); ?> </h2>
                </a>
                <?php woocommerce_template_loop_price(); ?>
                <?php woocommerce_template_single_rating() ?>
                <p> <?php echo wp_trim_words($short_description, 28, '') ?> </p>
                <div class="hover_content">
                    <?php if($opt['is_product_lightbox'] == '1') { ?>
                        <a href="#" data-toggle="modal" data-target="#myModal<?php echo get_the_ID(); ?>"><i class="icon_zoom-in_alt"></i></a>
                    <?php } ?>
                    <a href="?add-to-cart=<?php echo get_the_ID() ?>" title="<?php echo esc_attr($product->single_add_to_cart_text()) ?>">
                        <i class="icon_bag_alt"></i>
                    </a>
                    <?php echo shortcode_exists('ti_wishlists_addtowishlist') ? do_shortcode('[ti_wishlists_addtowishlist]') : ''; ?>
                </div>
            </div>
        </div>
    </div>

    <?php
    if($opt['is_product_lightbox'] == '1') {
        get_template_part('woocommerce/wc-template-parts/lightbox', 'content');
    }
    ?>
</div>