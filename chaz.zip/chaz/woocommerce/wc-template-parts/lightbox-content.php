<?php
global $product;
global $loop;
global $wc_loop_i;
global $post;
$featured_image_src = '';
if(isset($loop->post->ID)) {
    $featured_image_src = wp_get_attachment_image_src(get_post_thumbnail_id($loop->post->ID), 'single-post-thumbnail');
}
?>
<div class="modal fade modal_in modal_lightbox" id="myModal<?php echo get_the_ID(); ?>" role="dialog">
    <div class="modal_inner">
        <div class="modal_valign">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <?php
                                if(!empty($featured_image_src[0])) {
                                    the_post_thumbnail('chaz_365x385');
                                }
                                ?>
                            </div>
                            <div class="col-md-6">
                                <div class="product_details">
                                    <?php
                                    /**
                                     * Hook: woocommerce_single_product_summary.
                                     *
                                     * @hooked woocommerce_template_single_title - 5
                                     * @hooked woocommerce_template_single_rating - 10
                                     * @hooked woocommerce_template_single_price - 10
                                     * @hooked woocommerce_template_single_excerpt - 20
                                     * @hooked woocommerce_template_single_add_to_cart - 30
                                     * @hooked woocommerce_template_single_meta - 40
                                     * @hooked woocommerce_template_single_sharing - 50
                                     * @hooked WC_Structured_Data::generate_product_data() - 60
                                     */
                                    do_action( 'woocommerce_single_product_summary' );
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>