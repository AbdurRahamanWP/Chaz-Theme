<?php
global $wc_loop_i;
global $product;
$opt = get_option('chaz_opt');
$column = wc_get_loop_prop( 'columns' );
switch ($column) {
    case '3':
        $col = '4';
        break;
    case '4':
        $col = '3';
        break;
    case '2':
        $col = '6';
        break;
    default:
        $col = '4';
        break;
}
?>

<div <?php wc_product_class('col-md-'.$col.' col-sm-6'); ?>>
    <div class="single_product_item mb-40">
        <?php
        if (woocommerce_get_product_thumbnail()) {
            ?>
            <div class="product_img">
                <?php woocommerce_template_loop_product_thumbnail() ?>
                <?php echo wp_kses_post($product->is_on_sale()) ? '<div class="product_quary">'.esc_html__('Sale', 'chaz').'</div>' : ''; ?>
                <div class="hover_content">
                    <?php if($opt['is_product_lightbox'] == '1') { ?>
                        <a href="#" data-toggle="modal" data-target="#myModal<?php echo get_the_ID(); ?>"><i class="icon_zoom-in_alt"></i></a>
                    <?php } ?>
                    <a href="?add-to-cart=<?php echo get_the_ID() ?>" title="<?php echo esc_attr($product->single_add_to_cart_text()) ?>"><i class="icon_bag_alt"></i></a>
                    <?php echo shortcode_exists('ti_wishlists_addtowishlist') ? do_shortcode('[ti_wishlists_addtowishlist]') : ''; ?>
                </div>
            </div>
            <?php
        }
        ?>
        <div class="single_pr_details">
            <a href="<?php the_permalink() ?>">
                <h2> <?php the_title(); ?> </h2>
            </a>
            <?php woocommerce_template_loop_price(); ?>
            <?php woocommerce_template_single_rating() ?>
        </div>
    </div>

    <?php
    if($opt['is_product_lightbox'] == '1') {
        get_template_part('woocommerce/wc-template-parts/lightbox', 'content');
    }
    ?>
</div>