<?php
/**
 * Checkout coupon form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/form-coupon.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 3.4.4
 */

defined( 'ABSPATH' ) || exit;

if ( ! wc_coupons_enabled() ) { // @codingStandardsIgnoreLine.
    return;
}

?>
<div class="row" id="checkout_top_forms">
    <?php
    if(!is_user_logged_in()) :
        ?>
        <div class="col-md-6 coupon_apply_form">
            <div class="checkout_content">
                    <!-- Login Form -->
                <div class="return_customer">
                    <i class="icon_profile"></i>
                    <?php esc_html_e('Returning customer?', 'chaz') ?> <a data-toggle="collapse" href="#coupon" aria-expanded="false" aria-controls="newsletter" class="collapsed">Click here to login</a>
                </div>
                <div id="coupon">
                    <form class="login_form" name="loginform" action="<?php echo esc_url( site_url( 'wp-login.php', 'login_post' ) ); ?>" method="post">
                        <div class="input-group">
                            <input type="text" name="log" class="form-control" placeholder="<?php esc_attr_e('Username', 'chaz') ?>">
                            <input type="password" name="pwd" class="form-control" placeholder="<?php esc_attr_e('Password', 'chaz') ?>">
                            <button class="btn btn-default btn-animated-none" type="submit" name="wp-submit">
                                <?php esc_html_e('Login', 'chaz') ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
    endif;
    ?>

    <div class="col-md-6 checkout_login_form">
        <div class="checkout_content">
            <!-- Coupon code apply form -->
            <div class="return_customer">
                <i class="icon_gift_alt"></i>
                <?php echo apply_filters( 'woocommerce_checkout_coupon_message', esc_html__( 'Have a coupon?', 'chaz' ) . ' <a data-toggle="collapse" href="#coupon_two" aria-expanded="false" aria-controls="newsletter" class="collapsed">' . esc_html__( 'Click here to enter your code', 'chaz' ) . '</a>' ); ?>
            </div>

            <div id="coupon_two">
                <form class="login_form coupon_form" method="post">
                    <!--<p><?php /*esc_html_e( 'If you have a coupon code, please apply it below.', 'chaz' ); */?></p>-->
                    <input type="text" name="coupon_code" class="form-control" placeholder="<?php esc_attr_e( 'Coupon code', 'chaz' ); ?>" id="coupon_code" value="" />
                    <button type="submit" class="btn btn-default btn-animated-none" name="apply_coupon" value="<?php esc_attr_e( 'Apply coupon', 'chaz' ); ?>">
                        <?php esc_html_e( 'Apply coupon', 'chaz' ); ?>
                    </button>
                    <div class="clear"></div>
                </form>
            </div>
        </div>
    </div>

</div>