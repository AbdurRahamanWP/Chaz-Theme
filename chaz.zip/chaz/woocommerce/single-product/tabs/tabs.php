<?php
/**
 * Single Product tabs
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/tabs/tabs.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 2.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Filter tabs and allow third parties to add their own.
 *
 * Each tab is an array containing title, callback and priority.
 * @see woocommerce_default_product_tabs()
 */
$tabs = apply_filters( 'woocommerce_product_tabs', array() );
$is_active = ($i==0) ? 'active' : '';
$is_true_false = ($i==0) ? 'true' : 'false';
if ( ! empty( $tabs ) ) : ?>

	<div class="col-md-12">
        <div class="pr_description-tab">
            <div class="pr_tab mt-90 mb-60">
                <ul class="nav nav-tabs" role="tablist">
                    <?php
                    $i = 0;
                    foreach ( $tabs as $key => $tab ) : ?>
                        <li class="<?php echo esc_attr($is_active) ?>" role="presentation">
                            <a href="#tab-<?php echo esc_attr( $key ); ?>" aria-controls="#tab-<?php echo esc_attr( $key ); ?>" role="tab" data-toggle="tab" aria-expanded="<?php echo esc_attr($is_true_false) ?>">
                                <?php echo apply_filters( 'woocommerce_product_' . $key . '_tab_title', esc_html( $tab['title'] ), $key ); ?>
                            </a>
                        </li>
                    <?php ++$i; endforeach; ?>
                </ul>
            </div>
            <div class="tab-content">
            <?php
            $tab_content_i = 0;
            foreach ( $tabs as $key => $tab ) :
                $is_tab_content_active = ($tab_content_i==0) ? 'active' : '';
                ?>
                <div class=" <?php echo esc_attr($is_tab_content_active) ?> tab-pane" id="tab-<?php echo esc_attr( $key ); ?>" role="tabpanel">
                    <?php if ( isset( $tab['callback'] ) ) { call_user_func( $tab['callback'], $key, $tab ); } ?>
                </div>
            <?php ++$tab_content_i; endforeach; ?>
            </div>
        </div>
	</div>

<?php endif; ?>
