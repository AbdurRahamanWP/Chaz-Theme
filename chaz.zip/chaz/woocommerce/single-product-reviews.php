<?php
/**
 * Display single product reviews (comments)
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product-reviews.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.5.0
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

global $product;

if ( ! comments_open() ) {
    return;
}

?>
<div role="tabpanel" class="tab-pane" id="profile">
    <div class="row">
        <div class="col-md-6">
            <div class="review_tab">
                <?php
                wp_list_comments(
                    apply_filters(
                        'woocommerce_product_review_list_args',
                        array( 'callback' => 'chaz_woocommerce_comments' )
                    ),
                    get_comments(array(
                        'post_id' => get_the_ID(),
                    ))
                );
                ?>
            </div>
        </div>

        <?php if ( get_option( 'woocommerce_review_rating_verification_required' ) === 'no' || wc_customer_bought_product( '', get_current_user_id(), $product->get_id() ) ) : ?>
            <div class="col-md-6">
                <div class="review_form">
                    <?php
                    $commenter = wp_get_current_commenter();

                    $comment_form = array(
                        'title_reply'          => have_comments() ? __( 'Add a review', 'chaz' ) : sprintf( __( 'Be the first to review &ldquo;%s&rdquo;', 'chaz' ), get_the_title() ),
                        'title_reply_to'       => __( 'Leave a Reply to %s', 'chaz' ),
                        'title_reply_before'   => '<h1 class="comment-form-title mt-0 mb-30">',
                        'title_reply_after'    => '</h1>',
                        'comment_notes_after'  => '',
                        'fields'               => array(
                            'author' => '<div class="row-form row">
                                            <div class="col-form col-md-12">
                                                <div class="form-group">
                                                    <input type="text" name="author" class="form-control" placeholder="'.esc_attr__('Name *', 'chaz').'" value="' . esc_attr( $commenter['comment_author'] ) . '" aria-required="true" required>
                                                </div>
                                            </div>',
                            'email'  => '<div class="col-form col-md-12">
                                            <div class="form-group">
                                                <input name="email" type="text" class="form-control" placeholder="'.esc_attr__('Email *', 'chaz').'" value="' . esc_attr( $commenter['comment_author_email'] ) . '" aria-required="true" required>
                                            </div>
                                        </div>
                                    </div>',
                        ),
                        'label_submit'  => esc_html__( 'Submit Your Review', 'chaz' ),
                        'logged_in_as'  => '',
                        'comment_field' => '',
                        'class_form'    => 'comment-form',
                        'id_form'       => 'form-comments',
                        'class_submit'  => 'btn btn-candy btn-md btn-circle remove-margin btn-animated-none',
                        'id_submit'     => 'submit-btn'
                    );

                    if ( $account_page_url = wc_get_page_permalink( 'myaccount' ) ) {
                        $comment_form['must_log_in'] = '<p class="must-log-in">' . sprintf( __( 'You must be <a href="%s">logged in</a> to post a review.', 'chaz' ), esc_url( $account_page_url ) ) . '</p>';
                    }

                    if ( get_option( 'woocommerce_enable_review_rating' ) === 'yes' ) {
                        $comment_form['comment_field'] = '<div class="comment-form-rating"><label for="rating">' . esc_html__( 'Your rating', 'chaz' ) . '</label>
                        <select name="rating" id="rating" aria-required="true" required>
							<option value="">' . esc_html__( 'Rate&hellip;', 'chaz' ) . '</option>
							<option value="5">' . esc_html__( 'Perfect', 'chaz' ) . '</option>
							<option value="4">' . esc_html__( 'Good', 'chaz' ) . '</option>
							<option value="3">' . esc_html__( 'Average', 'chaz' ) . '</option>
							<option value="2">' . esc_html__( 'Not that bad', 'chaz' ) . '</option>
							<option value="1">' . esc_html__( 'Very poor', 'chaz' ) . '</option>
						</select></div>';
                    }

                    $comment_form['comment_field'] .= '<div class="form-group"> <textarea id="comment-field" class="form-control" placeholder="'.esc_attr__('Your Review', 'chaz').'" rows="5" name="comment" aria-required="true" required></textarea></p>';

                    comment_form( apply_filters( 'woocommerce_product_review_comment_form_args', $comment_form ) );
                    ?>
                </div>
            </div>
            <?php
        endif;
        ?>
    </div>
</div>
