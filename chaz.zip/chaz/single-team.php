<?php
/**
 * Single page template for displaying single team member
 */
get_header();
$opt = get_option('chaz_opt');
$is_related_services = !empty($opt['is_related_services']) ? $opt['is_related_services'] : '1';
$related_service_title = !empty($opt['related_service_title']) ? $opt['related_service_title'] : esc_html__('Related services', 'chaz');

$team_metas = get_post_meta(get_the_ID(), 'team_metas', true);
$designation = isset($team_metas['designation']) ? $team_metas['designation'] : '';
$social_links = isset($team_metas['more_social_links']) ? $team_metas['more_social_links'] : '';
$attributes = isset($team_metas['atts']) ? $team_metas['atts'] : '';
?>
    <section class="white-bg sec_pad">
        <div class="container">
            <div class="row team_details">
                <div class="col-md-6 col-sm-12 pull-right">
                    <?php the_post_thumbnail('chaz_570x620') ?>
                </div>
                <div class="col-md-6 col-sm-12">
                    <div class="memder_details">
                        <h2> <?php the_title(); ?> </h2>
                        <?php if(!empty($designation)) : ?>
                            <h6> <?php echo esc_attr($designation) ?> </h6>
                        <?php endif; ?>
                        <?php
                        while(have_posts()): the_post();
                            the_content();
                        endwhile;
                        ?>
                        <ul class="about_details">
                            <?php
                            if(!empty($attributes)) {
                                foreach ($attributes as $attribute) {
                                    echo "<li><span> ".esc_attr($attribute['key']).":</span> ".esc_attr($attribute['value'])." </li>";
                                }
                            }
                            ?>
                        </ul>
                        <div class="social_icon">
                            <?php if(!empty($team_metas['facebook_url'])) : ?>
                            <a href="<?php echo esc_url($team_metas['facebook_url']) ?>"><i class="fa fa-facebook"></i></a>
                            <?php endif ?>
                            <?php if(!empty($team_metas['twitter_url'])) : ?>
                            <a href="<?php echo esc_url($team_metas['twitter_url']); ?>"><i class="fa fa-twitter"></i></a>
                            <?php endif; ?>
                            <?php if(!empty($team_metas['google_plus_url'])) : ?>
                            <a href="<?php echo esc_url($team_metas['google_plus_url']) ?>"><i class="fa fa-dribbble"></i></a>
                            <?php endif; ?>
                            <?php if(!empty($team_metas['linkedin_url'])) : ?>
                            <a href="<?php echo esc_url($team_metas['linkedin_url']) ?>"><i class="fa fa-linkedin"></i></a>
                            <?php endif; ?>
                            <?php
                            if(!empty($social_links)) {
                                foreach ($social_links as $social_link) {
                                    echo '<a href="'.esc_url($social_link['social_link']).'"><i class="'.esc_attr($social_link['social_icon']).'"></i></a>';
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row port_skilll mt-80">
                <?php if(!empty($team_metas['skill_title'])) : ?>
                    <div class="col-md-12 heading-style-two mb-30">
                        <h2 class="font-700 purple_br"><span> <?php echo esc_html($team_metas['skill_title']) ?> </span></h2>
                    </div>
                <?php endif; ?>
                <?php
                $skills = !empty($team_metas['skills']) ? $team_metas['skills'] : '';
                if(is_array($skills)) {
                    foreach ($skills as $skill) {
                        $color = !empty($skill['color']) ? $skill['color'] : '';
                        ?>
                        <div class="col-md-6">
                            <div class="mt-30">
                                <div class="progress-bar-title"> <?php echo esc_html($skill['name']) ?> </div>
                                <div class="pr-count"><span class="count"> <?php echo esc_html($skill['progress']) ?> </span>%</div>
                                <div class="progress">
                                    <div class="progress-bar" <?php echo !empty($color) ? "style='color: ".esc_attr($color).";'" : ''; ?> data-width="<?php echo esc_attr($skill['progress']) ?>"></div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                }
                ?>
            </div>
        </div>
    </section>

<?php
get_footer();