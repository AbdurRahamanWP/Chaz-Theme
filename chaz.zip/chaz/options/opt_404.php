<?php

Redux::setSection('chaz_opt', array(
    'title'     => esc_html__('404 Error Page', 'chaz'),
    'id'        => '404_0pt',
    'icon'      => 'dashicons dashicons-info',
    'fields'    => array(
        array(
            'title'     => esc_html__('Error Heading Text', 'chaz'),
            'id'        => 'error_heading',
            'type'      => 'text',
            'default'   => esc_html__("404", 'chaz')
        ),
        array(
            'title'     => esc_html__('Title', 'chaz'),
            'id'        => 'error_title',
            'type'      => 'text',
            'default'   => esc_html__("Looks Like you're Lost", 'chaz')
        ),
        array(
            'title'     => esc_html__('Subtitle', 'chaz'),
            'id'        => 'error_subtitle',
            'type'      => 'text',
            'default'   => esc_html__("We can't seem to find the page you're looking for", 'chaz')
        ),
        array(
            'title'     => esc_html__('Home button label', 'chaz'),
            'id'        => 'error_home_btn_label',
            'type'      => 'text',
            'default'   => esc_html__("Back to home", 'chaz')
        ),
    )
));
