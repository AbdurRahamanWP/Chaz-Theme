<?php

Redux::setSection('chaz_opt', array(
	'title'     => esc_html__('Blog Page', 'chaz'),
	'id'        => 'blog_page',
	'icon'      => 'dashicons dashicons-admin-post',
	'fields'    => array(
		array(
			'title'     => esc_html__('Blog page title', 'chaz'),
			'subtitle'  => esc_html__('Give here the blog page title', 'chaz'),
			'desc'      => esc_html__('This text will show on the blog page banner', 'chaz'),
			'id'        => 'blog_title',
			'type'      => 'text',
			'default'   => esc_html__('Blog List', 'chaz')
		),
		array(
			'title'     => esc_html__('Blog page subtitle', 'chaz'),
			'id'        => 'blog_subtitle',
			'type'      => 'text',
		),
		array(
			'title'     => esc_html__('Title bar background', 'chaz'),
			'subtitle'  => esc_html__('Upload image file as Blog page title bar background', 'chaz'),
			'id'        => 'blog_header_bg',
			'type'      => 'media',
		),
	)
));


Redux::setSection('chaz_opt', array(
	'title'     => esc_html__('Blog archive', 'chaz'),
	'id'        => 'blog_meta_opt',
	'icon'      => 'dashicons dashicons-info',
	'subsection' => true,
	'fields'    => array(
        array(
            'title'     => esc_html__('Blog excerpt', 'chaz'),
            'subtitle'  => esc_html__('How much words you want to show in blog page.', 'chaz'),
            'id'        => 'blog_excerpt',
            'type'      => 'text',
            'default'   => '20'
        ),
        array(
            'title'     => esc_html__('Read more link label', 'chaz'),
            'id'        => 'blog_read_more',
            'type'      => 'text',
            'default'   => 'Read More'
        ),
		array(
			'title'     => esc_html__('Social share', 'chaz'),
			'id'        => 'is_social_share',
			'type'      => 'switch',
            'on'        => esc_html__('Enabled', 'chaz'),
            'off'       => esc_html__('Disabled', 'chaz'),
            'default'   => '1'
		),
		array(
			'title'     => esc_html__('Post meta', 'chaz'),
			'subtitle'  => esc_html__('Show/hide post meta on blog archive page', 'chaz'),
			'id'        => 'is_post_meta',
			'type'      => 'switch',
            'on'        => esc_html__('Show', 'chaz'),
            'off'       => esc_html__('Hide', 'chaz'),
            'default'   => '1',
		),
		array(
			'title'     => esc_html__('Show/hide post author name', 'chaz'),
			'id'        => 'is_post_author',
			'type'      => 'switch',
            'on'        => esc_html__('Show', 'chaz'),
            'off'       => esc_html__('Hide', 'chaz'),
            'default'   => '1',
            'required' => array( 'is_post_meta', '=', 1 )
		),
		array(
			'title'     => esc_html__('Post date', 'chaz'),
			'id'        => 'is_post_date',
			'type'      => 'switch',
            'on'        => esc_html__('Show', 'chaz'),
            'off'       => esc_html__('Hide', 'chaz'),
            'default'   => '1',
            'required' => array( 'is_post_meta', '=', 1 )
		),
		array(
			'title'     => esc_html__('Post category', 'chaz'),
			'id'        => 'is_post_cat',
			'type'      => 'switch',
            'on'        => esc_html__('Show', 'chaz'),
            'off'       => esc_html__('Hide', 'chaz'),
            'default'   => '1',
            'required' => array( 'is_post_meta', '=', 1 )
		),
	)
));


Redux::setSection('chaz_opt', array(
	'title'     => esc_html__('Blog single', 'chaz'),
	'id'        => 'blog_single_opt',
	'icon'      => 'dashicons dashicons-info',
	'subsection' => true,
	'fields'    => array(
		array(
			'title'     => esc_html__('Social share', 'chaz'),
			'id'        => 'is_social_share',
			'type'      => 'switch',
            'on'        => esc_html__('Enabled', 'chaz'),
            'off'       => esc_html__('Disabled', 'chaz'),
            'default'   => '1'
		),
		array(
			'title'     => esc_html__('Post tag', 'chaz'),
			'id'        => 'is_post_tag',
			'type'      => 'switch',
            'on'        => esc_html__('Show', 'chaz'),
            'off'       => esc_html__('Hide', 'chaz'),
            'default'   => '1'
		),
        array(
            'title'     => esc_html__('Related posts ', 'chaz'),
            'id'        => 'is_related_posts',
            'type'      => 'switch',
            'on'        => esc_html__('Show', 'chaz'),
            'off'       => esc_html__('Hide', 'chaz'),
            'default'   => ''
        ),
        array(
            'title'     => esc_html__('Related posts section title', 'chaz'),
            'id'        => 'related_posts_title',
            'type'      => 'text',
            'default'   => esc_html__('Related Post', 'chaz'),
            'required'  => array('is_related_posts', '=', '1')
        ),
        array(
            'title'     => esc_html__('Show related posts count', 'chaz'),
            'id'        => 'related_posts_count',
            'type'      => 'slider',
            'default'       => 3,
            'min'           => 3,
            'step'          => 1,
            'max'           => 50,
            'display_value' => 'label',
            'required'  => array('is_related_posts', '=', '1')
        ),
	)
));
