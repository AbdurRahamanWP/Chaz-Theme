<?php
Redux::setSection('chaz_opt', array(
    'title'            => esc_html__( 'General Settings', 'chaz' ),
    'id'               => 'opt_gen',
    'icon'             => 'dashicons dashicons-star-filled',
    'fields'           => array(
        array(
            'title'     => esc_html__('Pre-loader', 'chaz'),
            'id'        => 'is_preloader',
            'type'      => 'switch',
            'default'   => false,
            'on'        => esc_html__('Enabled', 'chaz'),
            'off'       => esc_html__('Disabled', 'chaz'),
        ),
    )
));