<?php

Redux::setSection('chaz_opt', array(
    'title'     => esc_html__('Service single page', 'chaz'),
    'id'        => 'service_opt',
    'icon'      => 'dashicons dashicons-format-aside',
    'fields'    => array(

        array(
            'title'     => esc_html__('Related services', 'chaz'),
            'id'        => 'is_related_services',
            'type'      => 'switch',
            'on'        => esc_html__('Show', 'chaz'),
            'off'       => esc_html__('Hide', 'chaz'),
            'default'   => '1'
        ),

        array(
            'title'     => esc_html__('Related service title', 'chaz'),
            'subtitle'  => esc_html__('Enter here the related service section title.', 'chaz'),
            'id'        => 'related_service_title',
            'type'      => 'text',
            'default'   => esc_html__('Related services you may know', 'chaz'),
            'required'  => array('is_related_services', '=', '1')
        ),

        array(
            'title'     => esc_html__('Show related services count', 'chaz'),
            'id'        => 'related_services_count',
            'type'      => 'slider',
            'default'       => 3,
            'min'           => 3,
            'step'          => 1,
            'max'           => 50,
            'display_value' => 'label',
            'required'  => array('is_related_services', '=', '1')
        ),

        array(
            'title'     => esc_html__('Show related services count', 'chaz'),
            'id'        => 'related_services_count',
            'type'      => 'slider',
            'default'       => 3,
            'min'           => 3,
            'step'          => 1,
            'max'           => 30,
            'display_value' => 'label',
            'required'  => array('is_related_services', '=', '1')
        ),

    )
));