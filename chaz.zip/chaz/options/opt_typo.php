<?php

// Typography section
Redux::setSection('chaz_opt', array(
	'title'     => esc_html__('Typography', 'chaz'),
	'desc'     => esc_html__('Theme Typography Options', 'chaz'),
	'id'        => 'typography',
	'icon'      => 'dashicons dashicons-editor-textcolor',
	'fields'    => array(
		array(
			'id'            => 'body-typo',
			'type'          => 'typography',
			'title'         => esc_html__( 'Body Font', 'chaz' ),
			'subtitle'      => esc_html__( 'Specify the body font properties.', 'chaz' ),
			'line-height'   => false,
			'google'        => false,
			'text-align'    => false,
			'default'  => array(
				'font-family'   => '\'Hind\', sans-serif',
				'font-weight'   => '400',
				'color'         => '#505050',
				'font-size'     => '14px',
			),
			'output'  => 'body'
		),
		array(
			'id'       => 'heading-typo',
			'type'     => 'typography',
			'title'    => esc_html__( 'Heading font', 'chaz' ),
			'subtitle' => esc_html__( 'Specify the h1,h2,h3,h4,h5,h6 font properties.', 'chaz' ),
			'font-backup'   => false,
			'line-height'   => false,
			'text-align'    => false,
			'font-size'     => false,
			'google'        => false,
			'color'         => false,
			'default'  => array(
				'font-family'   => '\'Raleway\', sans-serif;',
				'font-weight'   => 'normal',
			),
			'output'    => 'h1,h2,h3,h4,h5,h6'
		),
		array(
			'id'          => 'page-title-bar-typo',
			'type'        => 'typography',
			'title'       => esc_html__( 'Page title bar', 'chaz' ),
			'subtitle'    => esc_html__( 'Typography options for page title bar', 'chaz' ),
			'compiler'      => true,
			'font-backup'   => false,
			'font-family'   => false,
			'google'        => false,
			'line-height'   => false,
			'text-align'    => false,
			'units'       => 'px',
			'default'     => array(
				'color'         => '#ffffff',
				'font-size'     => '30px',
				'font-weight'   => '800',
			),
			'output'    => '.page-banner h1'
		),
	)
));