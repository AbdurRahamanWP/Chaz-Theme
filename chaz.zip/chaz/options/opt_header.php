<?php

// Header Section
Redux::setSection('chaz_opt', array(
    'title'            => esc_html__( 'Header Settings', 'chaz' ),
    'id'               => 'header_sec',
    'customizer_width' => '400px',
    'icon'             => 'el el-home'
) );


Redux::setSection('chaz_opt', array(
    'title'            => esc_html__( 'Logo', 'chaz' ),
    'id'               => 'logo_opt',
    'subsection'       => true,
    'icon'             => 'dashicons dashicons-schedule',
    'fields'           => array(

        array(
            'title'     => esc_html__('Logo Type', 'chaz'),
            'id'        => 'logo_type',
            'type'      => 'button_set',
            'default'   => 'image',
            'options'   => array(
                'image' => esc_html__('Image Logo', 'chaz'),
                'text'  => esc_html__('Text Logo', 'chaz'),
            )
        ),

        array(
            'title'     => esc_html__('Text Logo', 'chaz'),
            'id'        => 'text_logo',
            'type'      => 'text',
            'default'   => get_bloginfo('name'),
            'required'  => array('logo_type', '=', 'text')
        ),

        array(
            'title'     => esc_html__('Text Logo Typography', 'chaz'),
            'id'        => 'text_logo_typo',
            'type'      => 'typography',
            'output'    => array( '.navbar-brand h3' ),
            'required'  => array('logo_type', '=', 'text')
        ),

        array(
            'title'     => esc_html__('Upload logo', 'chaz'),
            'subtitle'  => esc_html__( 'Upload here a image file for your logo', 'chaz' ),
            'id'        => 'main_logo',
            'type'      => 'media',
            'compiler'  => true,
            'required'  => array('logo_type', '=', 'image'),
            'default'   => array(
                'url'   => chaz_DIR_IMG.'/logo-white.png'
            )
        ),

        array(
            'title'     => esc_html__('Sticky header logo', 'chaz'),
            'id'        => 'sticky_logo',
            'type'      => 'media',
            'compiler'  => true,
            'required'  => array('logo_type', '=', 'image'),
            'default'   => array(
                'url'   => chaz_DIR_IMG.'/logo-dark.png'
            )
        ),

        array(
            'title'     => esc_html__('Retina logo', 'chaz'),
            'subtitle'  => esc_html__( 'The retina logo will visible on only retina display and the logo would be 2x of your original logo.', 'chaz' ),
            'id'        => 'retina_logo',
            'type'      => 'media',
            'compiler'  => true,
            'required'  => array('logo_type', '=', 'image'),
            'default'   => array(
                'url'   => chaz_DIR_IMG.'/logo-white@2x.png'
            )
        ),

        array(
            'title'     => esc_html__('Retina sticky logo', 'chaz'),
            'subtitle'  => esc_html__( 'The retina logo will visible on only retina display and the logo would be 2x of your original logo.', 'chaz' ),
            'id'        => 'sticky_retina_logo',
            'type'      => 'media',
            'compiler'  => true,
            'required'  => array('logo_type', '=', 'image'),
            'default'   => array(
                'url'   => chaz_DIR_IMG.'/logo-dark@2x.png'
            )
        ),

        array(
            'title'     => esc_html__('Padding', 'chaz'),
            'subtitle'  => esc_html__('Padding around the logo. Input the padding as clockwise (Top Right Bottom Left)', 'chaz'),
            'id'        => 'logo_padding',
            'type'      => 'spacing',
            'output'    => array( '.navbar .navbar-header .navbar-brand' ),
            'mode'      => 'padding',
            'units'     => array( 'em', 'px', '%' ),      // You can specify a unit value. Possible: px, em, %
            'units_extended' => 'true',
            'default'   => array(
                'padding-top'    => '0px',
                'padding-right'  => '0px',
                'padding-bottom' => '0px',
                'padding-left'   => '0px'
            )
        ),

    )
) );


// Navbar styling
Redux::setSection('chaz_opt', array(
    'title'            => esc_html__( 'Navbar Styling', 'chaz' ),
    'id'               => 'navbar_styling',
    'subsection'       => true,
    'icon'             => 'el el-brush',
    'fields'           => array(

        array(
            'title'     => esc_html__('Navbar layout', 'chaz'),
            'id'        => 'navbar_layout',
            'type'      => 'image_select',
            'default'   => 'boxed',
            'options'   => array(
                'boxed' => array(
                    'alt' => esc_html__('Boxed layout', 'chaz'),
                    'img' => chaz_DIR_IMG.'/layouts/menu_boxed_1.jpg',
                ),
                'full_width' => array(
                    'alt' => esc_html__('Full Width', 'chaz'),
                    'img' => chaz_DIR_IMG.'/layouts/menu_fluid_1.jpg',
                ),
            )
        ),

        array(
            'title'     => esc_html__('Menu Layout', 'chaz'),
            'id'        => 'menu_layout',
            'type'      => 'image_select',
            'default'   => 'right',
            'options'   => array(
                'right' => array(
                    'alt' => esc_html__('Right Aligned', 'chaz'),
                    'img' => chaz_DIR_IMG.'/layouts/menu_boxed_1.jpg',
                ),
                'center' => array(
                    'alt' => esc_html__('Center Aligned', 'chaz'),
                    'img' => chaz_DIR_IMG.'/layouts/menu_boxed_2.jpg',
                ),
            )
        ),

        array(
            'title'     => esc_html__('Menu color', 'chaz'),
            'subtitle'  => esc_html__('Menu item font color', 'chaz'),
            'id'        => 'menu_font_color',
            'output'    => '.navbar .navbar-nav .menu-item a, .navbar .attr-nav ul li.dropdown.cart-menu a i',
            'type'      => 'link_color',
        ),

        array(
            'title'         => esc_html__('Menu Font Properties', 'chaz'),
            'id'            => 'menu_font_typo',
            'type'          => 'typography',
            'text-align'    => false,
            'font-weight'   => false,
            'font-style'   => false,
            'output'        => '.navbar .nav li > a',
            'preview'       => array(
                'always_display' => false
            )
        ),

        array(
            'title'     => esc_html__('Font weight', 'chaz'),
            'subtitle'  => esc_html__('Menu item font weight.', 'chaz'),
            'id'        => 'menu_font_weight',
            'type'      => 'select',
            'options'   => array(
                'normal' => esc_html__('Normal', 'chaz'),
                'bold'   => esc_html__('Bold', 'chaz'),
                'bolder' => esc_html__('Bolder', 'chaz'),
                '300'   => '300',
                '400'   => '400',
                '500'   => '500',
                '600'   => '600',
                '700'   => '700',
                '800'   => '800',
                '900'   => '900',
            ),
            'default'   => '400',
        ),

        array(
            'title'     => esc_html__('Text Transform', 'chaz'),
            'subtitle'  => esc_html__('Menu item font text transform.', 'chaz'),
            'id'        => 'menu_text_transform',
            'type'      => 'select',
            'options'   => array(
                'initial' => esc_html__('Initial', 'chaz'),
                'capitalize' => esc_html__('Capitalize', 'chaz'),
                'lowercase' => esc_html__('Lowercase', 'chaz'),
                'uppercase' => esc_html__('Uppercase', 'chaz'),
                'none' => esc_html__('None', 'chaz'),
            ),
            'default'   => 'none',
        ),

        array(
            'title'     => esc_html__('Sticky menu color', 'chaz'),
            'subtitle'  => esc_html__('Menu item font color on sticky menu mode.', 'chaz'),
            'id'        => 'sticky_menu_font_color',
            'output'    => '.navbar.shrink .navbar-nav .menu-item a',
            'type'      => 'color',
        ),

        array(
            'title'     => esc_html__('Sticky menu background color', 'chaz'),
            'id'        => 'sticky_menu_bg_color',
            'output'    => '.navbar.shrink',
            'type'      => 'color',
            'mode'      => 'background',
        ),

        array(
            'title'     => esc_html__('Menu item padding', 'chaz'),
            'subtitle'  => esc_html__('Padding around menu item.', 'chaz'),
            'id'        => 'menu_item_padding',
            'type'      => 'spacing',
            'output'    => array( '.navbar .navbar-nav .menu-item' ),
            'mode'      => 'margin',
            'units'     => array( 'em', 'px', '%' ),      // You can specify a unit value. Possible: px, em, %
            'units_extended' => 'true',
            'default'   => array(
                'margin-top'    => '0px',
                'margin-right'  => '40px',
                'margin-bottom' => '0px',
                'margin-left'   => '0px'
            )
        ),

    )
));

// Title-bar
Redux::setSection('chaz_opt', array(
    'title'            => esc_html__( 'Cart Icon', 'chaz' ),
    'id'               => 'cart_icon_opt',
    'subsection'       => true,
    'icon'             => 'dashicons dashicons-cart',
    'fields'           => array(

        array(
            'title'     => esc_html__('Cart Icon', 'chaz'),
            'id'        => 'is_cart_icon',
            'type'      => 'switch',
            'default'   => false,
            'on'        => esc_html__('Show', 'chaz'),
            'off'       => esc_html__('Hide', 'chaz'),
        ),

    )
));


// Title-bar
Redux::setSection('chaz_opt', array(
    'title'            => esc_html__( 'Title-bar', 'chaz' ),
    'id'               => 'title_bar_opt',
    'subsection'       => true,
    'icon'             => 'dashicons dashicons-schedule',
    'fields'           => array(

        array(
            'title'     => esc_html__('Title-bar overlay color', 'chaz'),
            'id'        => 'title_bar_overlay_color',
            'type'      => 'color_rgba',
            'mode'      => 'background',
            'default'   => array(
                'color' => '#212121',
                'alpha' => '.85'
            ),
            'output'    => array('.title-hero-bg::before')
        ),

        array(
            'title'     => esc_html__('Title-bar padding', 'chaz'),
            'id'        => 'title_bar_padding',
            'type'      => 'spacing',
            'output'    => array( '.banner-area' ),
            'mode'      => 'padding',
            'units'     => array( 'em', 'px', '%' ),      // You can specify a unit value. Possible: px, em, %
            'units_extended' => 'true',
            'default'   => array(
                'padding-top'    => '240px',
                'padding-right'  => '0px',
                'padding-bottom' => '187px',
                'padding-left'   => '0px'
            ),
        ),

        array(
            'title'         => esc_html__('Title font properties', 'chaz'),
            'id'            => 'titlebar_title_typo',
            'type'          => 'typography',
            'google'        => false,
            'text-align'    => false,
            'default'       => array(
                'font-family'   => '\'Poppins\', sans-serif',
                'color'         => '#fff',
                'font-size'     => '65px',
                'line-height'   => '85px'
            ),
            'output'  => '.page-title h1',
            'preview' => array(
                'always_display' => false
            )
        ),

        array(
            'title'         => esc_html__('Subtitle font properties', 'chaz'),
            'id'            => 'titlebar_subtitle_typo',
            'type'          => 'typography',
            'google'        => false,
            'text-align'    => false,
            'default'       => array(
                'font-family'   => '\'Poppins\', sans-serif',
                'font-weight'   => '600',
                'color'         => '#fff',
                'font-size'     => '25px',
                'line-height'   => '35px'
            ),
            'output'  => 'section.title-hero-bg.parallax-effect .page-title h4'
        ),

    )
));

