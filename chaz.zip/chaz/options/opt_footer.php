<?php

// Footer settings
Redux::setSection('chaz_opt', array(
	'title'     => esc_html__('Footer Settings', 'chaz'),
	'id'        => 'chaz_footer',
	'icon'      => 'dashicons dashicons-download',
	'fields'    => array(
		array(
			'title'     => esc_html__('Copyright text', 'chaz'),
			'subtitle'  => esc_html__('Footer Copyright text', 'chaz'),
			'id'        => 'copyright_txt',
			'type'      => 'editor',
			'default'   => wp_kses_post(__('© 2020 <a href="http://droitthemes.com">DroitThemes</a>. All rights reserved', 'chaz')),
			'args'    => array(
				'wpautop'       => true,
				'media_buttons' => false,
				'textarea_rows' => 5,
				'teeny'         => false,
				'quicktags'     => false,
			)
		),
        array(
            'title'     => esc_html__('Footer logo', 'chaz'),
            'id'        => 'footer_logo',
            'type'      => 'media',
            'compiler'  => true,
            'default'   => array(
                'url' => chaz_DIR_IMG.'/logo-b.png'
            )
        ),
        array(
            'title'     => esc_html__('Footer logo URL', 'chaz'),
            'id'        => 'footer_logo_url',
            'type'      => 'text',
            'default'  =>  esc_url(home_url('/'))
        ),
	)
));