<?php

// Map settings
Redux::setSection('chaz_opt', array(
    'title'     => esc_html__('Map settings', 'chaz'),
    'id'        => 'map_settings',
    'icon'      => 'dashicons dashicons-chart-area',
    'fields'    => array(
        array(
            'title'     => esc_html__('Map API key', 'chaz'),
            'subtitle'  => wp_kses_post(__('Enter her your Google map API key. Get it from <a href="https://developers.google.com/maps/documentation/javascript/get-api-key">here</a>', 'chaz')),
            'id'        => 'map_api',
            'type'      => 'text',
        ),
        array(
            'title'     => esc_html__('Place name', 'chaz'),
            'id'        => 'place_name',
            'type'      => 'text',
            'default'   => esc_html__('Chaos', 'chaz'),
        ),
        array(
            'title'     => esc_html__('Map latitude key', 'chaz'),
            'subtitle'  => wp_kses_post(__('Get the latitude from <a href="https://www.latlong.net/">here</a>', 'chaz')),
            'id'        => 'latitude',
            'type'      => 'text',
            'default'   => esc_html__('42.008315', 'chaz')
        ),
        array(
            'title'     => esc_html__('Map Longitude key', 'chaz'),
            'subtitle'  => wp_kses_post(__('Get the Longitude from <a href="https://www.latlong.net/">here</a>', 'chaz')),
            'id'        => 'longitude',
            'type'      => 'text',
            'default'   => esc_html__('-88.163807', 'chaz')
        ),
        array(
            'title'     => esc_html__('Map zoom label', 'chaz'),
            'id'        => 'map_zoom',
            'type'      => 'slider',
            'default'       => 12,
            'min'           => 5,
            'step'          => 1,
            'max'           => 100,
            'display_value' => 'label',
        ),
        array(
            'title'     => esc_html__('Place marker icon', 'chaz'),
            'id'        => 'map_marker',
            'type'      => 'media',
            'compiler'  => true,
            'default'   => array(
                'url'   => chaz_DIR_IMG.'/pin.png'
            )
        ),
    )
));