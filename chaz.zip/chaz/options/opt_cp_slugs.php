<?php

// Footer settings
Redux::setSection('chaz_opt', array(
    'title'     => esc_html__('Slug Re-write', 'chaz'),
    'id'        => 'chaz_cp_slugs',
    'icon'      => 'dashicons dashicons-admin-links',
    'fields'    => array(
        array(
            'title'     => esc_html__('Service Slug', 'chaz'),
            'subtitle'  => esc_html__('Save the Permalinks Settings From Settings > Permalinks after changing the slug value.', 'chaz'),
            'id'        => 'service_slug',
            'type'      => 'text',
            'default'   => 'service'
        ),
        array(
            'title'     => esc_html__('Portfolio Slug', 'chaz'),
            'subtitle'  => esc_html__('Save the Permalinks Settings From Settings > Permalinks after changing the slug value.', 'chaz'),
            'id'        => 'portfolio_slug',
            'type'      => 'text',
            'default'   => 'portfolio'
        ),
        array(
            'title'     => esc_html__('Team Slug', 'chaz'),
            'subtitle'  => esc_html__('Save the Permalinks Settings From Settings > Permalinks after changing the slug value.', 'chaz'),
            'id'        => 'team_slug',
            'type'      => 'text',
            'default'   => 'team'
        ),
    )
));