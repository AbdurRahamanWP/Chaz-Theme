<?php
get_header();
$opt = get_option('chaz_opt');
?>
    <section class="portfolio_details_area white-bg sec_pad">
        <div class="container">
            <?php
            while ( have_posts() ) : the_post(); ?>
                <div class="portfolio_details">
                    <?php if(has_post_thumbnail(get_the_ID())) : ?>
                        <div class="p_details_img">
                            <?php the_post_thumbnail() ?>
                        </div>
                    <?php endif; ?>
                    <div class="portfolio_details_content">
                        <div class="portfolio_category">
                            <?php
                            $portfolio_metas = get_post_meta(get_the_ID(), 'portfolio_metas', true);
                            $attributes = !empty($portfolio_metas['atts']) ? $portfolio_metas['atts'] : '';
                            $is_share = !empty($portfolio_metas['is_share']) ? $portfolio_metas['is_share'] : '';
                            if(is_array($attributes)) {
                                foreach ($attributes as $attribute) { ?>
                                    <div class="category_item">
                                        <h6><?php echo esc_html($attribute['key']) ?>:</h6>
                                        <p><?php echo esc_html($attribute['value']) ?></p>
                                    </div>
                                    <?php
                                }
                            }
                            ?>
                            <?php if($is_share=='1') : ?>
                                <div class="category_item">
                                    <h6> <?php esc_html_e('Share On:', 'chaz') ?> </h6>
                                    <ul>
                                        <li><a href="https://facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="https://twitter.com/intent/tweet?text=<?php the_permalink(); ?>"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="https://www.pinterest.com/pin/create/button/?url=<?php the_permalink() ?>"><i class="fa fa-pinterest"></i></a></li>
                                        <li><a href="https://plus.google.com/share?url=<?php the_permalink() ?>"><i class="fa fa-google-plus"></i></a></li>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php the_content(); ?>
                        <div class="hr mt-30"></div>
                        <div class="row portfolio_pagination mt-30">
                            <?php if(get_previous_post()) : ?>
                            <div class="col-xs-4">
                                <div class="por_pagination_btn prev"><i class="eicon arrow_left"></i>
                                    <span> <?php previous_post_link('%link' , esc_html__('Prev', 'chaz')); ?> </span>
                                </div>
                            </div>
                            <?php endif; ?>
                            <div class="col-xs-4 text-center">
                                <?php
                                $archive_link = $opt['is_portfolio_custom_archive']=='1' ? $opt['portfolio_custom_archive_url'] : get_post_type_archive_link('portfolio');
                                ?>
                                <a href="<?php echo esc_url($archive_link) ?>" class="por_pagination_btn"><i class="fa fa-th-large"></i></a>
                            </div>
                            <?php if(get_next_post()) : ?>
                            <div class="col-xs-4 text-right">
                                <div class="por_pagination_btn next">
                                    <span><?php next_post_link('%link ', esc_html__('Next', 'chaz')); ?></span><i class="eicon arrow_right"></i>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </section>
<?php
get_footer();