<?php
/**
 * Single page template for displaying service single post
 */
get_header();
$opt = get_option('chaz_opt');
$is_related_services = !empty($opt['is_related_services']) ? $opt['is_related_services'] : '1';
$related_service_title = !empty($opt['related_service_title']) ? $opt['related_service_title'] : '';
$related_service_subtitle = !empty($opt['related_service_subtitle']) ? $opt['related_service_subtitle'] : '';
?>
    <section class="service_details-area white-bg sec_pad">
        <div class="container s_content">
            <?php
            while ( have_posts() ) : the_post();
                the_content();
            endwhile;
            ?>
        </div>
    </section>

    <?php

    $related = get_posts( array(
        'category__in' => wp_get_post_categories($post->ID),
        'numberposts' => !empty($opt['related_services_count']) ? $opt['related_services_count'] : 3,
        'post__not_in' => array($post->ID),
        'post_type' => 'service'
    ));

    if($related & $is_related_services == '1') : ?>
        <section class="sec_overflow_hidden related_posts_sec related_services_sec">
            <div class="hexagon-gradient-left shapes"></div>
            <div class="triangle-light-blue shapes"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12 heading-style-two text-center">
                        <?php if(!empty($related_service_subtitle)) : ?>
                            <h6 class="pink-color font-600"> <?php echo esc_html($related_service_subtitle) ?> </h6>
                        <?php endif; ?>
                        <?php if(!empty($related_service_title)) : ?>
                            <h2 class="font-700 purple_br"> <?php echo esc_html($related_service_title) ?> </h2>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mt-90 display-flex">
                    <?php
                    foreach( $related as $post ) {
                        setup_postdata($post);
                        $service_metas = get_post_meta(get_the_ID(), 'service_metas', true);
                        $icon = isset($service_metas['icon']) ? $service_metas['icon'] : '';
                        $icon_color = isset($service_metas['icon_color']) ? $service_metas['icon_color'] : '';
                        ?>
                        <div class="col-md-4 main-service-box text-center">
                            <i class="<?php echo esc_attr($icon); ?> default-color" <?php echo !empty($icon_color) ? "style='color: ".esc_attr($icon_color).";'" : ''; ?>></i>
                            <a href="<?php the_permalink() ?>"> <h4> <?php the_title(); ?> </h4> </a>
                            <p> <?php the_excerpt(); ?> </p>
                        </div>
                        <?php
                        wp_reset_postdata();
                    }
                    ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

<?php
get_footer();