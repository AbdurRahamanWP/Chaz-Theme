<?php
$options[]    = array(
    'id'        => 'page_metas',
    'title'     => esc_html__('Title bar', 'chaz'),
    'post_type' =>  array('page'),
    'context'   => 'normal',
    'priority'  => 'default',
    'sections'  => array(
        array(
            'name'  => 'page_title_bar',
            'icon'  => 'dashicons dashicons-minus',
            'fields' => array(
                array(
                    'id'        => 'is_page_titlebar',
                    'type'      => 'switcher',
                    'title'     => esc_html__('Title Bar', 'chaz'),
                    'default'   => true
                ),
                array(
                    'id'        => 'page_subtitle',
                    'type'      => 'text',
                    'title'     => esc_html__('Subtitle', 'chaz'),
                    'dependency' => array('is_page_titlebar', '==', 'true')
                ),
            ),
        ),
    ),
);