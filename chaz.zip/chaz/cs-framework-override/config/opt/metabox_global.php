<?php
$options[]    = array(
    'id'        => 'post_metas',
    'title'     => esc_html__('Title-bar Options', 'chaz'),
    'post_type' =>  array('post', 'product'),
    'context'   => 'normal',
    'priority'  => 'default',
    'sections'  => array(
        array(
            'name'  => 'post_titlebar',
            'icon'  => 'dashicons dashicons-minus',
            'fields' => array(
                array(
                    'id'        => 'post_bg',
                    'type'      => 'upload',
                    'title'     => esc_html__('Background image', 'chaz'),
                    'settings'      => array(
                        'upload_type'  => 'image',
                    ),
                ),
                array(
                    'id'        => 'post_title',
                    'type'      => 'text',
                    'title'     => esc_html__('Title', 'chaz'),
                    'default'   => 'Single page',
                ),
                array(
                    'id'        => 'post_subtitle',
                    'type'      => 'text',
                    'title'     => esc_html__('Subtitle', 'chaz'),
                ),
            ),
        ),
    ),
);