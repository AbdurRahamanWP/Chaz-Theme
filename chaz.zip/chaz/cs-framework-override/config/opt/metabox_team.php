<?php
$options[]    = array(
    'id'        => 'team_metas',
    'title'     => esc_html__('Member information', 'chaz'),
    'post_type' =>  array('team'),
    'context'   => 'normal',
    'priority'  => 'default',
    'sections'  => array(

        array(
            'name'  => 'general_info',
            'title' => esc_html__('General information', 'chaz'),
            'icon'  => 'dashicons dashicons-info',
            'fields' => array(
                array(
                    'id'        => 'designation',
                    'type'      => 'text',
                    'title'     => esc_html__('Member designation', 'chaz'),
                    'desc'      => esc_html__('Leave this field blank to hide.', 'chaz'),
                    'default'   => 'Founder & CEO',
                ),
                array(
                    'id'        => 'title_bar_bg',
                    'title'     => esc_html__('Title-bar background', 'chaz'),
                    'desc'      => esc_html__('Upload here a high resolution image for title-bar background', 'chaz'),
                    'type'      => 'upload',
                    'settings'      => array(
                        'upload_type'  => 'image',
                    ),
                ),
                array(
                    'id'              => 'atts',
                    'type'            => 'group',
                    'title'           => esc_html__('Extra Attributes', 'chaz'),
                    'button_title'    => esc_html__('Add Attribute', 'chaz'),
                    'accordion_title' => esc_html__('Adding New Attribute', 'chaz'),
                    'fields'          => array(
                        array(
                            'id'          => 'key',
                            'type'        => 'text',
                            'title'       => esc_html__('Attribute name', 'chaz'),
                        ),
                        array(
                            'id'          => 'value',
                            'type'        => 'text',
                            'title'       => esc_html__('Attribute value', 'chaz'),
                        ),
                    )
                ),
            ),
        ),

        array(
            'name'  => 'social_accounts',
            'title' => esc_html__('Social accounts', 'chaz'),
            'icon'  => 'dashicons dashicons-networking',
            'fields' => array(
                array(
                    'id'        => 'facebook_url',
                    'type'      => 'text',
                    'title'     => esc_html__('Facebook URL', 'chaz'),
                    'desc'      => esc_html__('Leave this field blank to hide.', 'chaz'),
                    'default'   => '#',
                ),
                array(
                    'id'        => 'twitter_url',
                    'type'      => 'text',
                    'title'     => esc_html__('Facebook URL', 'chaz'),
                    'desc'      => esc_html__('Leave this field blank to hide.', 'chaz'),
                    'default'   => '#',
                ),
                array(
                    'id'        => 'google_plus_url',
                    'type'      => 'text',
                    'title'     => esc_html__('Google plus URL', 'chaz'),
                    'desc'      => esc_html__('Leave this field blank to hide.', 'chaz'),
                    'default'   => '#',
                ),
                array(
                    'id'        => 'linkedin_url',
                    'type'      => 'text',
                    'title'     => esc_html__('Linkedin plus URL', 'chaz'),
                    'desc'      => esc_html__('Leave this field blank to hide.', 'chaz'),
                    'default'   => '#',
                ),
                array(
                    'id'              => 'more_social_links',
                    'type'            => 'group',
                    'title'           => esc_html__('Add more social links', 'chaz'),
                    'button_title'    => esc_html__('Add new', 'chaz'),
                    'accordion_title' => esc_html__('Adding New Social Link', 'chaz'),
                    'fields'          => array(
                        array(
                            'id'          => 'social_icon',
                            'type'        => 'icon',
                            'title'       => esc_html__('Icon', 'chaz'),
                        ),
                        array(
                            'id'          => 'social_link',
                            'type'        => 'text',
                            'title'       => esc_html__('Link', 'chaz'),
                            'default'     => '#'
                        ),
                    )
                ),
            )
        ),

        array(
            'name'  => 'skill_sec',
            'title' => esc_html__('Skill section', 'chaz'),
            'icon'  => 'dashicons dashicons-editor-table',
            'fields' => array(
                array(
                    'id'        => 'skill_title',
                    'type'      => 'text',
                    'title'     => esc_html__('Skill section title', 'chaz'),
                    'default'   => 'Check My Skills',
                ),
                array(
                    'id'              => 'skills',
                    'type'            => 'group',
                    'title'           => esc_html__('Skills', 'chaz'),
                    'button_title'    => esc_html__('Add skill', 'chaz'),
                    'accordion_title' => esc_html__('Adding new skill', 'chaz'),
                    'fields'          => array(
                        array(
                            'id'          => 'name',
                            'type'        => 'text',
                            'title'       => esc_html__('Skill name', 'chaz'),
                        ),
                        array(
                            'id'          => 'progress',
                            'type'        => 'number',
                            'title'       => esc_html__('Skill progress', 'chaz'),
                            'subtitle'    => esc_html__('Enter the skill progress within 100%', 'chaz'),
                            'default'     => '90'
                        ),
                        array(
                            'id'          => 'color',
                            'type'        => 'color_picker',
                            'title'       => esc_html__('Skill progressbar color', 'chaz'),
                            'default'     => '#ff5f6d'
                        ),
                    )
                ),
            ),
        ),

    ),
);