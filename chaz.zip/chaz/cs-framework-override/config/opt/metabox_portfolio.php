<?php
$options[]    = array(
    'id'        => 'portfolio_metas',
    'title'     => esc_html__('Portfolio settings', 'chaz'),
    'post_type' =>  array('portfolio'),
    'context'   => 'normal',
    'priority'  => 'default',
    'sections'  => array(
        array(
            'name'  => 'portfolio_titlebar',
            'title' => esc_html__('Title-bar', 'chaz'),
            'icon'  => 'dashicons dashicons-minus',
            'fields' => array(
                array(
                    'id'        => 'portfolio_bg',
                    'type'      => 'upload',
                    'title'     => esc_html__('Background image', 'chaz'),
                    'settings'      => array(
                        'upload_type'  => 'image',
                    ),
                ),
                array(
                    'id'        => 'subtitle',
                    'type'      => 'text',
                    'title'     => esc_html__('Subtitle', 'chaz'),
                ),
            ),
        ),
        array(
            'name'  => 'column',
            'title'  => esc_html__('Other settings', 'chaz'),
            'icon'  => 'dashicons dashicons-minus',
            'fields' => array(
                array(
                    'id'        => 'set_column',
                    'type'      => 'select',
                    'title'     => esc_html__('Column', 'chaz'),
                    'desc'      => esc_html__('Set the portfolio column size. This portfolio will take space within this column width.', 'chaz'),
                    'options'   => array(
                        '4' => '4/12',
                        '3' => '3/12',
                        '6' => '6/12'
                    )
                ),
                array(
                    'id'        => 'is_share',
                    'type'      => 'switcher',
                    'title'     => esc_html__('Social share', 'chaz'),
                    'default'   => true
                ),
                array(
                    'id'              => 'atts',
                    'type'            => 'group',
                    'title'           => esc_html__('Extra Attributes', 'chaz'),
                    'button_title'    => esc_html__('Add Attribute', 'chaz'),
                    'accordion_title' => esc_html__('Adding New Attribute', 'chaz'),
                    'fields'          => array(
                        array(
                            'id'          => 'key',
                            'type'        => 'text',
                            'title'       => esc_html__('Attribute name', 'chaz'),
                        ),
                        array(
                            'id'          => 'value',
                            'type'        => 'text',
                            'title'       => esc_html__('Attribute value', 'chaz'),
                        ),
                    )
                ),
            ),
        ),
    ),
);