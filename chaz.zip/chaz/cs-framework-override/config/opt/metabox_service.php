<?php
$options[]    = array(
    'id'        => 'service_metas',
    'title'     => esc_html__('Portfolio settings', 'chaz'),
    'post_type' =>  array('service'),
    'context'   => 'side',
    'priority'  => 'default',
    'sections'  => array(
        array(
            'name'  => 'column',
            'icon'  => 'dashicons dashicons-minus',
            'fields' => array(
                array(
                    'id'        => 'subtitle',
                    'type'      => 'text',
                    'title'     => esc_html__('Subtitle', 'chaz'),
                    'desc'      => esc_html__('Service subtitle will show under the service title.', 'chaz'),
                ),
                array(
                    'id'        => 'icon',
                    'type'      => 'icon',
                    'title'     => esc_html__('Featured icon', 'chaz'),
                    'default'   => 'fa fa-heart',
                ),
                array(
                    'id'        => 'icon_color',
                    'type'      => 'color_picker',
                    'title'     => esc_html__('Icon color', 'chaz'),
                    'default'   => '#ff5f6d',
                ),
            ),
        ),
    ),
);