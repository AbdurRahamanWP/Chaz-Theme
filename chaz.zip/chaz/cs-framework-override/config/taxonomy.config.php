<?php
// Silence is golden.

$options      = array();

$options[]   = array(
    'id'       => '_portfolio_cat_config',
    'taxonomy' => 'portfolio_cat',
    'fields'   => array(
        array(
            'id'    => 'port_cat_banner_subtitle',
            'title' => esc_html__('Banner Title', 'chaz'),
            'type'  => 'text',
        ),
        array(
            'id'    => 'port_cat_banner_bg',
            'title' => esc_html__('Banner background image', 'chaz'),
            'type'          => 'upload',
            'settings'      => array(
                'upload_type'  => 'image',
            ),
        ),

    ),
);

CSFramework_Taxonomy::instance( $options );