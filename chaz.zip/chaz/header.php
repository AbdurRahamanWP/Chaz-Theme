<?php
$opt = get_option('chaz_opt');

$navbar_layout_set = !empty($opt['navbar_layout']) ? $opt['navbar_layout'] : '';
$menu_layout_set = !empty($opt['menu_layout']) ? $opt['menu_layout'] : '';

if($navbar_layout_set == 'boxed') {
    $navbar_layout = 'container';
}elseif($navbar_layout_set == 'full_width') {
    $navbar_layout = 'container-fluid';
}else {
    $navbar_layout = 'container';
}

if($menu_layout_set == 'center') {
    $menu_layout = 'center_menu';
}else{
    $menu_layout = '';
}

$is_preloader = !empty($opt['is_preloader']) ? $opt['is_preloader'] : '';

$main_logo_page    = function_exists('get_field') ? get_field('main_logo') : '';
$sticky_logo_page  = function_exists('get_field') ? get_field('sticky_logo') : '';

?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <!-- For IE -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- For Resposive Device -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <?php wp_head(); ?>
    </head>

<body <?php body_class(); ?>>
<?php
    if ( function_exists( 'wp_body_open' ) ) {
        wp_body_open();
    }
    ?>

    <?php if($is_preloader == '1') { ?>
        <div id="loader-overlay">
            <div class="loader">
                <div class="loader-inner"></div>
            </div>
        </div>
    <?php } ?>

    <!--=== Wrapper Start ===-->
    <div class="wrapper">
        <!--=== Header Start ===-->
        <header class="header_area navbar-fixed-top affix-top" data-spy="affix" data-offset-top="1">
            <div class="<?php echo esc_attr($navbar_layout) ?>">
                <nav class="navbar navbar-default">

                    <?php get_template_part('template-parts/header-parts/mini', 'cart') ?>

                    <div class="navbar-header">
                        <a class="navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
                            <?php
                            if($opt['logo_type'] == 'image') {

                               if(!empty($main_logo_page)){ ?>
                                <img src="<?php echo esc_url($main_logo_page['url']); ?>" alt="<?php bloginfo('name'); ?>">
                                <img src="<?php echo esc_url($sticky_logo_page['url']); ?>"  alt="<?php bloginfo('name'); ?>">
                                <?php             
                                }else{
                                    if (!empty($opt['main_logo']['url'])) {
                                        $sticky_logo = isset($opt['sticky_logo'] ['url']) ? $opt['sticky_logo'] ['url'] : '';
                                        $retina_logo = isset($opt['retina_logo'] ['url']) ? $opt['retina_logo'] ['url'] : '';
                                        $sticky_retina_logo = isset($opt['sticky_retina_logo'] ['url']) ? $opt['sticky_retina_logo'] ['url'] : '';
                                        if (!is_404()) { ?>
                                            <img src="<?php echo esc_url($opt['main_logo']['url']); ?>"
                                                 data-rjs="<?php echo esc_url($retina_logo) ?>"
                                                 alt="<?php bloginfo('name'); ?>">
                                            <img src="<?php echo esc_url($sticky_logo); ?>"
                                                 data-rjs="<?php echo esc_url($sticky_retina_logo) ?>"
                                                 alt="<?php bloginfo('name'); ?>">
                                            <?php
                                        } else {
                                            ?> <img src="<?php echo esc_url($sticky_logo); ?>"
                                                    alt="<?php bloginfo('name'); ?>"> <?php
                                        }
                                    } 
                                
                                else {
                                    echo '<h3>' . get_bloginfo('name') . '</h3>';
                                }
                                }  // End Page Logo Option Condition
                            }
                            elseif($opt['logo_type'] == 'text') {
                                echo '<h3>' .esc_attr($opt['text_logo']). '</h3>';
                            }
                            else {
                                echo '<h3>' . get_bloginfo('name') . '</h3>';
                            }
                            ?>
                        </a>
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#menu_id" aria-expanded="false">
                            <span class="sr-only"><?php esc_html_e('Toggle navigation', 'chaz') ?> </span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>

                    <!--========== Collect the nav links, forms, and other content for toggling ==========-->
                    <?php
                    if(has_nav_menu('main_menu')) {
                        wp_nav_menu(array(
                            'menu' => 'main_menu',
                            'theme_location' => 'main_menu',
                            'container_class' => 'collapse navbar-collapse '.$menu_layout,
                            'container_id' => 'menu_id',
                            'menu_class' => 'nav navbar-nav navbar-right',
                            'walker' => new chaz_Nav_Navwalker,
                            'fallback_cv' => 'chaz_Nav_Navwalker::fallback',
                            'depth' => 3
                        ));
                    }
                    ?>
                </nav>
            </div>
        </header>

    <?php
    get_template_part('template-parts/header-parts/title', 'bar');
