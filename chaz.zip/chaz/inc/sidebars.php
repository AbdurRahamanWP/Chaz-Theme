<?php
// Register Widget areas
add_action('widgets_init', function() {

    register_sidebar(array(
        'name'          => esc_html__('Sidebar widgets', 'chaz'),
        'description'   => esc_html__('Place widgets in sidebar widgets area.', 'chaz'),
        'id'            => 'sidebar_widgets',
        'before_widget' => '<div id="%1$s" class="widget sidebar_widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h5 class="widget-title">',
        'after_title'   => '</h5>'
    ));

    if ( class_exists('WooCommerce') ) {
        register_sidebar(array(
            'name' => esc_html__('Shop sidebar', 'chaz'),
            'description' => esc_html__('Place widgets here for WooCommerce shop page.', 'chaz'),
            'id' => 'shop_sidebar',
            'before_widget' => '<div id="%1$s" class="mb-50 %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<h5 class="widget-title">',
            'after_title' => '</h5>'
        ));
    }

    register_sidebar(array(
        'name'          => esc_html__('Footer Sidebar', 'chaz'),
        'description'   => esc_html__('Add widgets here for Footer sidebar area', 'chaz'),
        'id'            => 'footer_sidebar',
        'before_widget' => '<div class="col-sm-6 col-md-3"> <div class="widget widget-links %2$s">',
        'after_widget'  => '</div> </div>',
        'before_title'  => '<h5 class="widget-title">',
        'after_title'   => '</h5>'
    ));

});