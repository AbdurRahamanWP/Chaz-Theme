<div class="lightProTable">
    <div class="table-responsive">
        <table class="table">
            <tbody>
            <tr>
                <th><?php echo __('Theme Features','chaz-lite'); ?></th>
                <th><?php echo __('Lite Version','chaz-lite'); ?></th>
                <th><?php echo __('Pro Version','chaz-lite'); ?></th>
            </tr>
            
             <tr>
                <td>Total Pages </td>
                <td>
                    <i class="dashicons">05</i>
                </td>
                <td>
                    <i class="dashicons">40+</i>
                </td>
            </tr>
            <tr>
                <td>Home Pages </td>
                <td>
                    <i class="dashicons">01</i>
                </td>
                <td>
                    <i class="dashicons">07+</i>
                </td>
            </tr>
            <tr>
                <td>Header Style </td>
                <td>
                    <i class="dashicons">01</i>
                </td>
                <td>
                    <i class="dashicons">04+</i>
                </td>
            </tr>
            <tr>
                <td> Footer Style </td>
                <td>
                    <i class="dashicons">01</i>
                </td>
                <td>
                    <i class="dashicons">02+</i>
                </td>
            </tr>
            
            <tr>
                <td>Element </td>
                <td>
                    <i class="dashicons">20+</i>
                </td>
                <td>
                    <i class="dashicons">80+</i>
                </td>
            </tr>
            <tr>
                <td><?php echo __('Pro Plugins','chaz-lite'); ?></td>
                <td>
                    <i class="dashicons dashicons-no-alt"></i>
                </td>
                <td>
                    <i class="dashicons dashicons-yes"></i>
                </td>
            </tr>
            <tr>
                <td><?php echo __('Multipage','chaz-lite'); ?></td>
                <td>
                    <i class="dashicons dashicons-no-alt"></i>
                </td>
                <td>
                    <i class="dashicons dashicons-yes"></i>
                </td>
            </tr>
            <tr>
                <td><?php echo __('RTL','chaz-lite'); ?></td>
                <td>
                    <i class="dashicons dashicons-no-alt"></i>
                </td>
                <td>
                    <i class="dashicons dashicons-yes"></i>
                </td>
            </tr>
            <tr>
                <td><?php echo __('Woocommerce','chaz-lite'); ?></td>
                <td>
                    <i class="dashicons dashicons-no-alt"></i>
                </td>
                <td>
                    <i class="dashicons dashicons-yes"></i>
                </td>
            </tr>

            <tr>
                <td><?php echo __('Update','chaz-lite'); ?></td>
                <td>
                    <i class="dashicons dashicons-no-alt"></i>
                </td>
                <td>
                    <i class="dashicons dashicons-yes"></i>
                </td>
            </tr>
           

           
            <tr>
                <td><?php echo __('Support','chaz-lite'); ?></td>
                <td>
                    <i class="dashicons dashicons-no-alt"></i>
                </td>
                <td>
                    <i class="dashicons dashicons-yes"></i>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
</div>

<!--
<div class="buyBtn text-center">
    <a href="https://themeforest.net/item/chaz_lite-landing-page-wordpress-theme/20421233?s_rank=14" class="btn btnBuy">Buy Pro</a>
</div>
-->

