<div class="support-process">
	<h3><?php echo esc_html__('Documentation', 'chaz'); ?></h3>
	<p><?php echo esc_html__('Read the detailed documentation of the theme. The documentation contain all the necessary information required to setup the theme VMagazine Lite.', 'chaz'); ?></p>
	<a class="button" target="_blank" href="https://droitthemes.com/docs/docs/chaz-wordpress-theme/"><?php echo esc_html__('Read Full Documentation', 'chaz'); ?></a>
</div>

<div class="support-process">
	<h3><?php echo esc_html__('Create Support Tickets', 'chaz'); ?></h3>
	<p><?php echo esc_html__('Still having problem after reading all the documentation? No Problem!! Please contact our support and we will help you.', 'chaz'); ?></p>
	<a class="button" target="_blank" href="mailto:support@droitthemes.com"><?php echo esc_html__('support@droitthemes.com', 'chaz'); ?></a>
</div>
