<?php
	/**
	 * Welcome Page Initiation
	*/

	include get_template_directory() . '/inc/welcome/welcome.php';

	/** Plugins **/
	$plugins = array(
		// *** Companion Plugins
		'companion_plugins' => array(),

		// *** Required Plugins
		'required_plugins' => array(

		),

		// *** Recommended Plugins
		'recommended_plugins' => array(

		),
	);

	$strings = array(
		// Welcome Page General Texts
		'welcome_menu_text' => esc_html__( 'Chaz  Setup', 'chaz' ),
		'theme_short_description' => esc_html__( 'Chaz is a new generation WordPress theme, that can give your readers immersive browsing experience. Malina blog theme polished & beautifully balanced pages make it an ideal WordPress template for almost all types of blog. Malina theme is ready to use with WordPress version 5.0+. Easy to use, no coding!', 'chaz' ),

		// Plugin Action Texts
		'install_n_activate' => esc_html__('Install and Activate', 'chaz'),
		'deactivate' => esc_html__('Deactivate', 'chaz'),
		'activate' => esc_html__('Activate', 'chaz'),

		// Getting Started Section
		'doc_heading' => esc_html__('Step 1 - Documentation', 'chaz'),
		'doc_description' => esc_html__('Read the Documentation and follow the instructions to manage the site , it helps you to set up the theme more easily and quickly. The Documentation is very easy with its pictorial  and well managed listed instructions. ', 'chaz'),
		'doc_read_now' => esc_html__( 'Read Now', 'chaz' ),
		'cus_heading' => esc_html__('Step 2 - Redux Theme Options', 'chaz'),
		'cus_description' => esc_html__('Using the Theme Settings you can easily customize every aspect of the theme globally.', 'chaz'),
		'cus_read_now' => esc_html__( 'Go to Theme Settings', 'chaz' ),

		// Recommended Plugins Section
		'pro_plugin_title' => esc_html__( 'Pro Plugins', 'chaz' ),
		'pro_plugin_description' => esc_html__( 'Take Advantage of some of our Premium Plugins.', 'chaz' ),
		'free_plugin_title' => esc_html__( 'Free Plugins', 'chaz' ),
		'free_plugin_description' => esc_html__( 'These Free Plugins might be handy for you.', 'chaz' ),

		// Demo Actions
		'activate_btn' => esc_html__('Activate', 'chaz'),
		'installed_btn' => esc_html__('Activated', 'chaz'),
		'demo_installing' => esc_html__('Installing Demo', 'chaz'),
		'demo_installed' => esc_html__('Demo Installed', 'chaz'),
		'demo_confirm' => esc_html__('Are you sure to import demo content ?', 'chaz'),

		// Actions Required
		'req_plugins_installed' => esc_html__( 'All Recommended action has been successfully completed.', 'chaz' ),
		'customize_theme_btn' => esc_html__( 'Customize Theme', 'chaz' ),
	);

	/**
	 * Initiating Welcome Page
	*/
	$my_theme_wc_page = new constructera_Welcome( $plugins, $strings );
	