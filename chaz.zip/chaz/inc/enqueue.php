<?php

function chaz_scripts() {
	$opt = get_option('chaz_opt');
    /**
     * Register Google fonts.
     *
     * @return string Google fonts URL for the theme.
     */
    function chaz_fonts_url() {
        $fonts_url = '';
        $fonts     = array();
        $subsets   = '';

        /* translators: If there are characters in your language that are not supported by this font, translate this to 'off'. Do not translate into your own language. */
        if ( 'off' !== esc_html_x( 'on', "Lato font: on or off", 'chaz' ) ) {
            $fonts[] = "Lato:300,400,700,900";
        }
        /* translators: If there are characters in your language that are not supported by this font, translate this to 'off'. Do not translate into your own language. */
        if ( 'off' !== esc_html_x( 'on', "Poppins font: on or off", 'chaz' ) ) {
            $fonts[] = "Poppins:100,300,400,500,600,700";
        }
        /* translators: If there are characters in your language that are not supported by this font, translate this to 'off'. Do not translate into your own language. */
        if ( 'off' !== esc_html_x( 'on', "Open Sans font: on or off", 'chaz' ) ) {
            $fonts[] = "Open Sans:400,500,600,700";
        }

        if ( $fonts ) {
            $fonts_url = add_query_arg( array(
                'family' => urlencode( implode( '|', $fonts ) ),
                'subset' => urlencode( $subsets ),
            ), 'https://fonts.googleapis.com/css' );
        }

        return $fonts_url;
    }

    wp_enqueue_style('chaz-fonts',  chaz_fonts_url());
    wp_enqueue_style('bootstrap', chaz_DIR_CSS.'/bootstrap.min.css');
    wp_enqueue_style('elegant-icons', chaz_DIR_VEND.'/elegant/style.css');
    wp_enqueue_style('material-design-icons', chaz_DIR_CSS.'/mdi.min.css');
    wp_enqueue_style('font-awesome', chaz_DIR_CSS.'/font-awesome.min.css');
    wp_enqueue_style('chaz_gutenburg', chaz_DIR_CSS.'/chaz_gutenburg.css');
    wp_enqueue_style('cube-portfolio', chaz_DIR_CSS.'/cubeportfolio.css');
    wp_register_style('slick', chaz_DIR_CSS.'/slick.min.css');
    wp_enqueue_style('animate', chaz_DIR_CSS.'/animate.css');
    wp_register_style('flexslider', chaz_DIR_VEND.'/flexslider/flexslider.css');
    if(class_exists('WooCommerce')) {
        if (is_shop()) {
            wp_enqueue_style('bootstrap-select', chaz_DIR_CSS.'/bootstrap-select.min.css');
        }
    }
    wp_enqueue_style('chaz-wpd', chaz_DIR_CSS.'/wpd-style.css');
    if(is_rtl()) {
        wp_enqueue_style('bootstrap-rtl',  chaz_DIR_CSS.'/bootstrap-rtl.css');
    }
    wp_enqueue_style('chaz-main', chaz_DIR_CSS.'/style.css');
    wp_enqueue_style('chaz-responsive', chaz_DIR_CSS . '/responsive.css');
    wp_enqueue_style('chaz-root', get_stylesheet_uri());


    // ACF CSS Start
   
   if(function_exists('get_field')) {
     $dynamic_css_style = '';
        $menu_regular_color = function_exists('get_field') ? get_field('menu_regular_color') : '';
        $menu_hover_color   = function_exists('get_field') ? get_field('menu_hover_color') : '';
        $menu_active_color  = function_exists('get_field') ? get_field('menu_active_color') : '';


        if ( $menu_regular_color ) {
                $dynamic_css_style .= "
                .navbar .nav li > a{
                    color: $menu_regular_color !important;
                }";
        }


        if ( $menu_hover_color ) {
                $dynamic_css_style .= "
                .navbar .nav li > a:hover{
                    color: $menu_hover_color !important;
                }";
        }

        if ( $menu_active_color ) {
                $dynamic_css_style .= "
                .navbar .nav li > a:active{
                    color: $menu_active_color !important;
                }";
        }
    }

    wp_add_inline_style('chaz-root', $dynamic_css_style);

    // ACF CSS End


    $dynamic_css = '';
    if(!empty($opt['menu_font_weight'])) {
        $dynamic_css .= ".navbar .nav li > a {font-weight: {$opt['menu_font_weight']}; text-transform: {$opt['menu_text_transform']}}";
    }
    if(!empty($opt['menu_font_color']['regular'])) {
        $dynamic_css .= '
        .navbar-default .navbar-toggle .icon-bar {background: '.esc_attr($opt['menu_font_color']['regular']).';} 
        .header_area.affix .navbar .attr-nav ul li a i {color: '.esc_attr($opt['menu_font_color']['regular']).'}';
    }
    if(!empty($opt['accent_gradient']['to'])) {
        $dynamic_css .= '
        .hero-text-wrap .btn-gradient:before {
            background-image: -webkit-gradient(linear, left top, left bottom, from(rgba(0, 0, 0, 0.8))), radial-gradient(circle at top left, '.esc_attr($opt['accent_gradient']['from']).', '.esc_attr($opt['accent_gradient']['to']).');
            background-image: -webkit-linear-gradient(rgba(0, 0, 0, 0.8)), -webkit-radial-gradient(top left, circle, '.esc_attr($opt['accent_gradient']['from']).', '.esc_attr($opt['accent_gradient']['to']).');
            background-image: -o-linear-gradient(rgba(0, 0, 0, 0.8)), -o-radial-gradient(top left, circle, '.esc_attr($opt['accent_gradient']['from']).', '.esc_attr($opt['accent_gradient']['to']).');
            background-image: linear-gradient(rgba(0, 0, 0, 0.8)), radial-gradient(circle at top left, '.esc_attr($opt['accent_gradient']['from']).', '.esc_attr($opt['accent_gradient']['to']).');
        }
        .hero-text-wrap .btn-gradient:hover:before, .btn-gradient:focus:before {
          background: -webkit-gradient(linear, left top, right top, from('.esc_attr($opt['accent_gradient']['from']).'), to('.esc_attr($opt['accent_gradient']['to']).'));
          background: -webkit-linear-gradient(left, '.esc_attr($opt['accent_gradient']['from']).' 0%, '.esc_attr($opt['accent_gradient']['to']).' 100%);
          background: -o-linear-gradient(left, '.esc_attr($opt['accent_gradient']['from']).' 0%, '.esc_attr($opt['accent_gradient']['to']).' 100%);
          background: linear-gradient(left, '.esc_attr($opt['accent_gradient']['from']).' 0%, '.esc_attr($opt['accent_gradient']['to']).' 100%);
        }
        .progress-bar,
        .btn.btn-candy,
        .pricing-box:hover:after,
        .work_portfolio_filter .work_portfolio_f_item.active, .work_portfolio_filter .work_portfolio_f_item:hover {
          background-image: -moz-linear-gradient(0deg, '.esc_attr($opt['accent_gradient']['from']).' 0%, '.esc_attr($opt['accent_gradient']['to']).' 100%);
          background-image: -webkit-linear-gradient(0deg, '.esc_attr($opt['accent_gradient']['from']).' 0%, '.esc_attr($opt['accent_gradient']['to']).' 100%);
          background-image: -ms-linear-gradient(0deg, '.esc_attr($opt['accent_gradient']['from']).' 0%, '.esc_attr($opt['accent_gradient']['to']).' 100%);
        }
        .pricing-box:hover:after {
          background-image: -webkit-gradient(linear, left bottom, left top, from(#ff5f6d), to(#ffc371));
          background-image: -webkit-linear-gradient(bottom, '.esc_attr($opt['accent_gradient']['from']).' 0%, '.esc_attr($opt['accent_gradient']['to']).' 100%);
          background-image: -o-linear-gradient(bottom, '.esc_attr($opt['accent_gradient']['from']).' 0%, '.esc_attr($opt['accent_gradient']['to']).' 100%);
          background-image: linear-gradient(0deg, '.esc_attr($opt['accent_gradient']['from']).' 0%, '.esc_attr($opt['accent_gradient']['to']).' 100%);
        }
        .intro-img:before {
            -moz-border-image: -moz-linear-gradient(top, '.esc_attr($opt['accent_gradient']['from']).' 0%, '.esc_attr($opt['accent_gradient']['to']).' 100%);
            -webkit-border-image: -webkit-linear-gradient(to bottom, '.esc_attr($opt['accent_gradient']['from']).' 0%, '.esc_attr($opt['accent_gradient']['to']).' 100%);
            -o-border-image: -o-linear-gradient(top, '.esc_attr($opt['accent_gradient']['from']).' 0%, '.esc_attr($opt['accent_gradient']['to']).' 100%);
            border-image: -webkit-gradient(linear, left top, left bottom, from('.esc_attr($opt['accent_gradient']['from']).'), to('.esc_attr($opt['accent_gradient']['to']).'));
            border-image: linear-gradient(to bottom, '.esc_attr($opt['accent_gradient']['from']).' 0%, '.esc_attr($opt['accent_gradient']['to']).' 100%);
            border-image-slice: 1;
            z-index: -1;
        }
        .heading-style-one hr.gradient-bg, .heading-style-two h2 span:after,
        .btn.btn-candy:active {
          background-image: -webkit-linear-gradient(bottom, '.esc_attr($opt['accent_gradient']['from']).' 0%, '.esc_attr($opt['accent_gradient']['to']).' 100%);
          background-image: -o-linear-gradient(bottom, '.esc_attr($opt['accent_gradient']['from']).' 0%, '.esc_attr($opt['accent_gradient']['to']).' 100%);
          background-image: -webkit-gradient(linear, right top, left top, from('.esc_attr($opt['accent_gradient']['from']).'), to('.esc_attr($opt['accent_gradient']['to']).'));
          background-image: -webkit-linear-gradient(right, '.esc_attr($opt['accent_gradient']['from']).' 0%, '.esc_attr($opt['accent_gradient']['to']).' 100%);
          background-image: -o-linear-gradient(right, '.esc_attr($opt['accent_gradient']['from']).' 0%, '.esc_attr($opt['accent_gradient']['to']).' 100%);
          background-image: linear-gradient(to left, '.esc_attr($opt['accent_gradient']['from']).' 0%, '.esc_attr($opt['accent_gradient']['to']).' 100%);
        }
        ';
    }

    wp_add_inline_style('chaz-root', $dynamic_css);
    

    // Scripts
    $dynamic_js = '';
	wp_enqueue_script( 'bootstrap', chaz_DIR_JS.'/bootstrap.js', array('jquery'), '3.3.6', true );
	wp_enqueue_script( 'smooth-scroll', chaz_DIR_JS.'/smoothscroll.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'stellar', chaz_DIR_JS.'/stellar.js', array('jquery'), '0.6.2', true );

    wp_enqueue_script( 'isotope', chaz_DIR_VEND.'/isotope/isotope-min.js', array('jquery', 'stellar'), '3.0.1', true );

	wp_enqueue_script( 'magnific-popup', chaz_DIR_JS.'/magnific-popup.js', array('jquery'), '1.0.0', true );
	wp_enqueue_script( 'parallax', chaz_DIR_JS.'/parallax.js', array('jquery'), '1.0.0', true );
	wp_enqueue_script( 'viewport', chaz_DIR_JS.'/viewport.js', array('jquery'), '1.0.0', true );
	wp_enqueue_script( 'wow', chaz_DIR_JS.'/wow.js', array('jquery'), '1.1.2', true );

	wp_enqueue_script( 'slick', chaz_DIR_VEND.'/slick/slick.min.js', array('jquery'), '1.6.0', true );

    wp_enqueue_script( 'type-it', chaz_DIR_JS.'/type-it.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'validator', chaz_DIR_JS.'/validator-plugin.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'bootsnav', chaz_DIR_JS.'/bootsnav.js', array('jquery'), '1.0', true );
	wp_enqueue_script( 'cube-portfolio', chaz_DIR_JS.'/cube-portfolio.js', array('jquery'), '3.2.1', true );
	wp_enqueue_script( 'jquery-ui', chaz_DIR_VEND.'/ui-fliter/jquery-ui.js', array('jquery'), '41.11.4', true );
	wp_enqueue_script( 'retinajs', chaz_DIR_VEND.'/retinajs/dist/retina.min.js', array('jquery'), '1.3.0', true );

	if(class_exists('ReduxFrameworkPlugin')) {
        if(!empty($opt['map_api'])) {
            wp_enqueue_script('chaz_googleapis', 'https://maps.googleapis.com/maps/api/js?key=' . $opt['map_api'], null, '', true);
        }
        $latitude = !empty($opt['latitude']) ? $opt['latitude'] : '';
        $longitude = !empty($opt['longitude']) ? $opt['longitude'] : '';
        $map_zoom = !empty($opt['map_zoom']) ? $opt['map_zoom'] : '';
        $place_name = !empty($opt['place_name']) ? $opt['place_name'] : '';
        $map_marker = !empty($opt['map_marker']['url']) ? $opt['map_marker']['url'] : '';
        $dynamic_js .= 'if(jQuery("#myMap").length>0){var $latitude=' . esc_js($latitude) . ',$longitude=' . esc_attr($longitude) . ',$map_zoom=' . esc_js($map_zoom) . ',$marker_url="' . esc_js($map_marker) . '",style=[{featureType:"all",elementType:"geometry.fill",stylers:[{weight:"2.00"}]},{featureType:"all",elementType:"geometry.stroke",stylers:[{color:"#9c9c9c"}]},{featureType:"all",elementType:"labels.text",stylers:[{visibility:"on"}]},{featureType:"landscape",elementType:"all",stylers:[{color:"#f2f2f2"}]},{featureType:"landscape",elementType:"geometry.fill",stylers:[{color:"#ffffff"}]},{featureType:"landscape.man_made",elementType:"geometry.fill",stylers:[{color:"#ffffff"}]},{featureType:"poi",elementType:"all",stylers:[{visibility:"on"}]},{featureType:"road",elementType:"all",stylers:[{saturation:-100},{lightness:45}]},{featureType:"road",elementType:"geometry.fill",stylers:[{color:"#eeeeee"}]},{featureType:"road",elementType:"labels.text.fill",stylers:[{color:"#7b7b7b"}]},{featureType:"road",elementType:"labels.text.stroke",stylers:[{color:"#ffffff"}]},{featureType:"road.highway",elementType:"all",stylers:[{visibility:"simplified"}]},{featureType:"road.arterial",elementType:"labels.icon",stylers:[{visibility:"on"}]},{featureType:"transit",elementType:"all",stylers:[{visibility:"on"}]},{featureType:"water",elementType:"all",stylers:[{color:"#46bcec"},{visibility:"on"}]},{featureType:"water",elementType:"geometry.fill",stylers:[{color:"#c8d7d4"}]},{featureType:"water",elementType:"labels.text.fill",stylers:[{color:"#070707"}]},{featureType:"water",elementType:"labels.text.stroke",stylers:[{color:"#ffffff"}]}],map_options={center:new google.maps.LatLng($latitude,$longitude),zoom:$map_zoom,panControl:!0,zoomControl:!0,mapTypeControl:!0,streetViewControl:!0,mapTypeId:google.maps.MapTypeId.ROADMAP,scrollwheel:!1,styles:style},map=new google.maps.Map(document.getElementById("myMap"),map_options),marker=new google.maps.Marker({position:new google.maps.LatLng($latitude,$longitude),map:map,visible:!0,icon:$marker_url}),contentString=\'<div id="mapcontent"><p>'.esc_js($place_name).'</p></div>\',infowindow=new google.maps.InfoWindow({maxWidth:320,content:contentString});google.maps.event.addListener(marker,"click",function(){infowindow.open(map,marker)})}';
    }
	wp_enqueue_script( 'bootstrap-select', chaz_DIR_JS.'/bootstrap-select.min.js', array('jquery'), '1.12.4', true );


    $master_js = is_rtl() ? '/master-rtl.js' : '/master.js';

	wp_enqueue_script( 'chaz-master', chaz_DIR_JS.$master_js, array('jquery'), '1.0', true );

    wp_add_inline_script('chaz-master', $dynamic_js);

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }

    wp_localize_script( 'chaz-master', 'chaz_ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
}
add_action( 'wp_enqueue_scripts', 'chaz_scripts');


add_action('admin_enqueue_scripts', function() {
    wp_enqueue_style('chaz-admin', chaz_DIR_CSS.'/chaz_admin.css');
});
