<?php

add_action('woocommerce_before_add_to_cart_form', function() {
    echo '<div class="mt-30 mb-30">';
});


add_action('woocommerce_after_add_to_cart_form', function() {
    echo '</div>';
});

add_action('woocommerce_after_add_to_cart_button', function() {
    echo shortcode_exists('ti_wishlists_addtowishlist') ? do_shortcode('[ti_wishlists_addtowishlist]') : '';
});


add_action('woocommerce_single_product_summary', function() {
    ?>
    <div class="share-link">
        <label> <?php esc_html_e('Share ON:', 'chaz') ?> </label>
        <ul class="social-icon">
            <li><a class="facebook" title="Facebook" href="https://facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>"><i class="fa fa-facebook"> </i></a></li>
            <li><a class="twitter" title="Twitter" href="https://twitter.com/intent/tweet?text=<?php the_permalink(); ?>"><i class="fa fa-twitter"> </i></a></li>
            <li><a class="linkedin" title="Linkedin" href="https://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink() ?>"><i class="fa fa-linkedin"> </i></a></li>
            <li><a class="rss" title="RSS" href="https://plus.google.com/share?url=<?php the_permalink() ?>"><i class="fa fa-google-plus"> </i></a></li>
        </ul>
    </div>
    <?php
}, 65);


remove_action('woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20);


/**
 * Checkout form fields customizing
 */
add_filter( 'woocommerce_checkout_fields' , function ( $fields ) {
    $fields['billing']['billing_first_name'] = array(
        'label'     => '',
        'placeholder'   => esc_html_x('First name *', 'placeholder', 'chaz'),
        'required'  => false,
        'class'     => array('col-md-6'),
        'clear'     => true
    );
    $fields['billing']['billing_last_name'] = array(
        'label'     => '',
        'placeholder'   => esc_html_x('Last name *', 'placeholder', 'chaz'),
        'required'  => false,
        'class'     => array('col-md-6'),
        'clear'     => true
    );
    $fields['billing']['billing_company'] = array(
        'label'     => '',
        'placeholder'   => esc_html_x('Company name (optional)', 'placeholder', 'chaz'),
        'required'  => false,
        'class'     => array('col-md-12'),
        'clear'     => true
    );
    $fields['billing']['billing_city'] = array(
        'label'     => '',
        'placeholder'   => esc_html_x('Town / City *', 'placeholder', 'chaz'),
        'class'     => array('col-md-12'),
        'clear'     => true
    );
    $fields['billing']['billing_postcode'] = array(
        'label'     => '',
        'placeholder' => esc_html_x('Postcode / ZIP (optional)', 'placeholder', 'chaz'),
        'class'     => array('col-md-12'),
        'clear'     => true
    );
    $fields['billing']['billing_phone'] = array(
        'label'     => '',
        'placeholder'   => esc_html_x('Phone', 'placeholder', 'chaz'),
        'required'  => false,
        'class'     => array('col-md-6'),
        'clear'     => true
    );
    $fields['billing']['billing_email'] = array(
        'label'     => '',
        'placeholder'   => esc_html_x('Email address *', 'placeholder', 'chaz'),
        'required'  => true,
        'class'     => array('col-md-6'),
        'clear'     => true
    );

    // Shipping Fields
    $fields['shipping']['shipping_first_name'] = array(
        'label'     => '',
        'placeholder'   => esc_html_x('First name *', 'placeholder', 'chaz'),
        'required'  => false,
        'class'     => array('col-md-6'),
        'clear'     => true
    );
    $fields['shipping']['shipping_last_name'] = array(
        'label'     => '',
        'placeholder'   => esc_html_x('Last name *', 'placeholder', 'chaz'),
        'required'  => false,
        'class'     => array('col-md-6'),
        'clear'     => true
    );
    $fields['shipping']['shipping_company'] = array(
        'label'     => '',
        'placeholder'   => esc_html_x('Company name (optional)', 'placeholder', 'chaz'),
        'required'  => false,
        'class'     => array('col-md-12'),
        'clear'     => true
    );
    $fields['shipping']['shipping_city'] = array(
        'label'     => '',
        'placeholder'   => esc_html_x('Town / City *', 'placeholder', 'chaz'),
        'class'     => array('col-md-12'),
        'clear'     => true
    );
    $fields['shipping']['shipping_postcode'] = array(
        'label'     => '',
        'placeholder' => esc_html_x('Postcode / ZIP (optional)', 'placeholder', 'chaz'),
        'class'     => array('col-md-12'),
        'clear'     => true
    );
    $fields['shipping']['shipping_phone'] = array(
        'label'     => '',
        'placeholder'   => esc_html_x('Phone', 'placeholder', 'chaz'),
        'required'  => false,
        'class'     => array('col-md-6'),
        'clear'     => true
    );
    $fields['shipping']['shipping_email'] = array(
        'label'     => '',
        'placeholder'   => esc_html_x('Email address *', 'placeholder', 'chaz'),
        'required'  => true,
        'class'     => array('col-md-6'),
        'clear'     => true
    );

    return $fields;
});


// WooCommerce review list
function chaz_woocommerce_comments($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment;
    extract($args, EXTR_SKIP);
    ?>
    <div class="media" id="comment-<?php comment_ID() ?>">
        <?php if(get_avatar($comment)) : ?>
        <div class="media-left">
            <?php echo get_avatar($comment, 70); ?>
        </div>
        <?php endif; ?>
        <div class="media-body">
            <h3> <?php comment_author(); ?> <span> <?php echo get_comment_time(get_option('date_format')); ?> </span></h3>
            <?php
            if ( $comment->comment_approved == '0' ) : ?>
                <em class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'chaz' ); ?></em>
            <?php endif; ?>
            <div class="rating">
                <?php woocommerce_review_display_rating() ?>
            </div>
            <p class="p_font"> <?php woocommerce_review_display_comment_text() ?> </p>
        </div>
    </div>
    <?php
}


// Enabling the gallery in themes that declare
add_theme_support( 'wc-product-gallery-zoom' );
add_theme_support( 'wc-product-gallery-lightbox' );
add_theme_support( 'wc-product-gallery-slider' );
