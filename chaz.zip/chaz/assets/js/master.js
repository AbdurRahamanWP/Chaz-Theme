/* ===================================================================

Author       	: Droitthemes
Template Name	: Chaos - Multi Purpose WordPress Theme
Version      	: 1.0

* ================================================================= */



/* ===== LOADER OVERLAY ===== */

(function ($) {
    'use strict';

    (function(){
        if( document.cookie.indexOf('device_pixel_ratio') == -1
            && 'devicePixelRatio' in window
            && window.devicePixelRatio == 2 ){

            var date = new Date();
            date.setTime( date.getTime() + 3600000 );

            document.cookie = 'device_pixel_ratio=' + window.devicePixelRatio + ';' +  ' expires=' + date.toUTCString() +'; path=/';
            //if cookies are not blocked, reload the page
            if(document.cookie.indexOf('device_pixel_ratio') != -1) {
                window.location.reload();
            }
        }
    })();


    function wc_review_tab() {
        $('.pr_description-tab .nav-tabs li').removeClass('active');
        $('.tab-content>.tab-pane').removeClass('active');
        $('.pr_description-tab .nav-tabs li:last-child').addClass('active');
        $('.tab-content>.tab-pane:last-child').addClass('active');
    }

    // Product parent category icon
    $('.shop_sidebar ul.product-categories>li.cat-parent>a').append('<i class="arrow_carrot-right"></i>');
    $('.shop_sidebar ul.product-categories>li.cat-parent>a').on('click', function (e) {
        e.preventDefault();
        $('.shop_sidebar ul.product-categories>li.cat-parent a i').toggleClass('arrow_rotated');
        $('.shop_sidebar ul.product-categories>li.cat-parent .children').toggle();
    });

    $('.ar_top').on('click', function () {
        var getID = $(this).next().attr('id');
        var result = document.getElementById(getID);
        var qty = result.value;
        $('.proceed_to_checkout .update-cart').removeAttr('disabled');
        if( !isNaN( qty ) ) {
            result.value++;
        }else{
            return false;
        }
    });

    $('.ar_down').on('click', function () {
        var getID = $(this).prev().attr('id');
        var result = document.getElementById(getID);
        var qty = result.value;
        $('.proceed_to_checkout .update-cart').removeAttr('disabled');
        if( !isNaN( qty ) && qty > 0 ) {
            result.value--;
        }else {
            return false;
        }
    });

    $(document).ready(function ($) {

        parallaxEffect();

        /* ===== PRELOADER  ===== */

        // Page loader
        $("#loader-overlay").delay(500).fadeOut();
        $(".loader").delay(1000).fadeOut("slow");



        $(window).trigger("scroll");
        $(window).trigger("resize");


        /*--------- cart-menu js-----------*/
        function cartActivitor(){
            if($(window).width()< 768){
                $('.cart-menu').on('click', function(){
                    if( $(this).hasClass('open') ){
                        $(this).removeClass('open')
                    }
                    else{
                        $(this).addClass('open')
                    }
                    return false
                });
            }
        }
        cartActivitor();

        /* ===== CBP PORTFOLIO ===== */
        var wow = new WOW({
                offset: 100,
                mobile: true
            }
        );
        wow.init();

        $('#chaos-gallery').cubeportfolio({
            filters: '#chaos-gallery-filter',
            layoutMode: 'grid',
            defaultFilter: '*',
            animationType: 'frontRow',
            gapHorizontal: 0,
            gapVertical: 0,
            gridAdjustment: '',
            mediaQueries: [{
                width: 1500,
                cols: 5
            }, {
                width: 1100,
                cols: 4
            }, {
                width: 800,
                cols: 3
            }, {
                width: 480,
                cols: 2
            }, {
                width: 320,
                cols: 1
            }],
            caption: 'overlayBottomAlong',
            displayType: 'bottomToTop',
            displayTypeSpeed: 300,
        });


        /* ===== PROGRESS BAR ===== */

        $(window).on('scroll', function(){
            progress_bars();

            var theta = $(window).scrollTop() / 200 % Math.PI;
            $('.hexagon-gradient-left, .triangle-light-blue, .polygon-box, .circle-box, #work .shapes').css({ transform: 'rotate(' + theta + 'rad)' });

            $('.port_skilll .count').each(function () {
                $(this).prop('Counter', 0).animate({
                    Counter: $(this).text()
                }, {
                    duration: 4000,
                    easing: 'swing',
                    step: function (now) {
                        $(this).text(Math.ceil(now));
                    }
                });
            });
        });

        function progress_bars() {
            $(".progress .progress-bar:in-viewport").each(function() {
                if (!$(this).hasClass("animated")) {
                    $(this).addClass("animated");
                    $(this).width($(this).attr("data-width") + "%");
                }

            });

        }



        /* ===== Sliders ===== */

        /* ~~~ Testimonial Slider Two ~~~ */
        function testimonialSliderTwo() {
            $(".testimonial-two").slick({
                dots: true,
                infinite: true,
                slidesToShow: 2,
                slidesToScroll: 2,
                centerPadding: '0',
                autoplay: true,
                autoplaySpeed: 2000,
                arrows: false,
                responsive: [
                    {
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2,
                            infinite: true,
                        }
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1
                        }
                    }
                ]
            });
        }
        testimonialSliderTwo();

        /* ===== One page Scroller ===== */

        $('a.page-scroll').on('click', function(event) {
            var $anchor = $(this);
            $('html, body').stop().animate({
                scrollTop: $($anchor.attr('href')).offset().top - 50
            }, 1000, 'easeInOutExpo');
            event.preventDefault();
        });



        /* ===== Parallax Effect===== */

        function parallaxEffect() {
            $('.parallax-effect').parallax();
        }


        /* ===== Parallax Stellar ===== */


        var isMobile = {
            Android: function () {
                return navigator.userAgent.match(/Android/i);
            },
            BlackBerry: function () {
                return navigator.userAgent.match(/BlackBerry/i);
            },
            iOS: function () {
                return navigator.userAgent.match(/iPhone|iPad|iPod/i);
            },
            Opera: function () {
                return navigator.userAgent.match(/Opera Mini/i);
            },
            Windows: function () {
                return navigator.userAgent.match(/IEMobile/i);
            },
            any: function () {
                return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
            }
        };

        jQuery(window).stellar({
            horizontalScrolling: false,
            hideDistantElements: true,
            verticalScrolling: !isMobile.any(),
            scrollProperty: 'scroll',
            responsive: true
        });

        /* ===== Search Overlay ===== */

        var wHeight = window.innerHeight;
        //search bar middle alignment
        $('#fullscreen-searchform').css('top', wHeight / 2);
        //reform search bar
        jQuery(window).resize(function() {
            wHeight = window.innerHeight;
            $('#fullscreen-searchform').css('top', wHeight / 2);
        });
        // Search
        $('#search-button').on('click', function () {
            $("div.fullscreen-search-overlay").addClass("fullscreen-search-overlay-show");
        });
        $('a.fullscreen-close').on('click', function () {
            $("div.fullscreen-search-overlay").removeClass("fullscreen-search-overlay-show");
        });



        /* ===== SKILLS BAR ===== */

        $('.skillbar').each(function(){
            $(this).find('.skillbar-bar').animate({
                width:jQuery(this).attr('data-percent')
            },6000);
        });

        /* ===== CONTACT FORM ===== */
        $('#contact-form').validator();



        /* === magnificPopup === */

        $('.image-lightbox').magnificPopup({
            type: 'image',
            mainClass: 'mfp-fade',
            removalDelay: 160,
            fixedContentPos: false
            // other options
        });

        $('.popup-youtube, .popup-vimeo, .popup-gmaps').magnificPopup({
            disableOn: 700,
            type: 'iframe',
            mainClass: 'mfp-fade',
            removalDelay: 160,
            preloader: false,
            fixedContentPos: false
        });

    });

    /*===========Portfolio isotope js===========*/
    function portfolioMasonry(){
        var portfolio = $("#work-portfolio,#blog_masonry");
        if( portfolio.length ){
            portfolio.imagesLoaded( function() {
                // images have loaded
                // Activate isotope in container
                portfolio.isotope({
                    itemSelector: ".work-item,.blog_item",
                    layoutMode: 'masonry',
                    transformsEnabled: true,
                    transitionDuration: "700ms",
                    masonry: {
                        // use element for option
                        columnWidth: '.grid-sizer'
                    }
                });

                // Add isotope click function
                $("#chaos_gallery_filter div").on('click',function(){
                    $("#chaos_gallery_filter div").removeClass("active");
                    $(this).addClass("active");

                    var selector = $(this).attr("data-filter");
                    portfolio.isotope({
                        filter: selector,
                        animationOptions: {
                            animationDuration: 750,
                            easing: 'linear',
                            queue: false
                        }
                    })
                    return false;
                });
            });
        }
    }
    portfolioMasonry();


    // Pricing Filter
    $(function() {
        $( "#slider-range" ).slider({
            range: true,
            min: 5,
            max: 150,
            values: [ 5, 100 ],
            slide: function( event, ui ) {
                $( "#amount" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
            }
        });
        $( "#amount" ).val( "$" + $( "#slider-range" ).slider( "values", 0 ) +
            " - $" + $( "#slider-range" ).slider( "values", 1 ) );
    });


    /*=============================================== 
      tooltip js
    ================================================*/
    $('[data-toggle="tooltip"]').tooltip();


    // Closes responsive menu when a scroll trigger link is clicked
    $('.navbar .nav li > a:not(.dropdown-toggle)').on('click', function() {
        $('.navbar-default .navbar-collapse').collapse('hide');
    });



})(jQuery);

/*End Jquery*/
